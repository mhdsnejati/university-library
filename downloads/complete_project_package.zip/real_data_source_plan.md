# Data Authenticity and Close-to-Real Source Plan

## Data Principle

For this course project, the submitted dataset is close-to-real assumed operational data. It is designed to behave like a real university library export: keys are consistent, dates are logical, reservations follow book demand, loans follow copy availability, and fines follow overdue/lost/damaged rules.

This is suitable for the assignment because the rubric asks for valid assumed/fictitious data that is meaningful, analyzable, and free of obvious contradictions.

## If Real Institutional Data Becomes Available

The same ERD and SQL schema can be reused with real exports. Real records should replace the assumed CSV files table by table.

| Source Export | Maps To | Notes |
|---|---|---|
| Branch/location list | library_branch | Can come from the university library website or admin system |
| Membership export | member | Must be anonymized before reporting |
| Staff/operator export | librarian | Can be anonymized or reduced to role-level records |
| Catalog/title export | book, author, publisher, category, book_author | ISBN, title, author, publisher, language, year |
| Inventory/copy export | book_copy | Barcode should be masked if public |
| Circulation/checkout export | loan | Required for fully real borrowing trends |
| Holds/reservations export | reservation | Required for fully real demand and purchase-need analysis |
| Fine/payment export | fine | Use only if allowed; otherwise aggregate or omit sensitive details |

## Public Catalog Enrichment Options

These sources can support real bibliographic metadata, but they do not replace the need for institutional operational records:

- Open Library data dumps: title, author, edition, ISBN, and work metadata.
- Library of Congress APIs: structured public metadata.
- The university's OPAC/catalog export, if available, is better than a generic public source because it matches actual holdings.

## What Should Not Be Claimed as Real Without Permission

| Table | Reason |
|---|---|
| member | Real member data is private and normally unavailable publicly |
| loan | Individual checkout histories are private and institution-specific |
| reservation | Holds/reservations are private and institution-specific |
| fine | Financial penalty records are private and institution-specific |

## Final Report Wording

Use this wording:

> The dataset is close-to-real assumed operational data generated from the ERD and business rules. It is not an official university export, but it follows realistic library behavior and passes consistency checks.

## Privacy Rules

1. Do not publish real names, phone numbers, emails, student IDs, or staff IDs without permission.
2. Replace member and staff identifiers with stable anonymized IDs before sharing.
3. Keep operational fields such as dates, statuses, branch, category, and amounts only when allowed.
4. If monetary fines are sensitive, use ranges or aggregated values.
5. Document each source, extraction date, and cleaning step if real data is later used.
