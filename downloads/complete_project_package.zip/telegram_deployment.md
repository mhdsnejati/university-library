# Telegram Bot Deployment Guide

## What This Bot Does

The Telegram bot uses the same validation rules as the project chatbot:

- Searches books.
- Reserves books after checking member and book validity.
- Checks active/overdue loans.
- Checks fine balances.
- Records lost/damaged item reports as validated tracking responses.
- Shows manager KPIs.
- Shows purchase-need recommendations.

## Commands

```text
/start
/search database
/reserve M000001 B000001
/loans M000001
/fines M000001
/report_issue M000001 LN000123 damaged
/kpis
/purchase_needs
```

## Run in Google Colab

```python
import os
os.environ["TELEGRAM_BOT_TOKEN"] = "PASTE_YOUR_BOTFATHER_TOKEN_HERE"
!python telegram_bot.py
```

Keep the Colab cell running while testing the bot in Telegram.

## Submission Note

Create the Telegram bot through BotFather, test the commands, then paste the bot link or username into `report/final_report.md`.
