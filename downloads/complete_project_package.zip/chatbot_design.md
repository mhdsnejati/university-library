# Telegram Chatbot Design

Project: Central University Library Management System
Platform: Telegram
Core file: `library_chatbot.py`
Telegram wrapper: `telegram_bot.py`

## Roles

- Manager: asks about KPIs, purchase needs, overdue risks, and branch performance.
- Analyst/operator: validates member IDs, loan status, copy availability, and reservation requests.
- External user/member: searches books, reserves books, checks loans, reports lost/damaged books, and checks fines.

## Telegram Command Map

| Command | Role | Example | Validation |
|---|---|---|---|
| `/start` | all | `/start` | Introduces allowed commands |
| `/search` | external user | `/search database` | Search text required |
| `/reserve` | external user | `/reserve M000001 B000001` | Member exists, active, not expired, book exists, no duplicate reservation, fine balance acceptable |
| `/loans` | external user/operator | `/loans M000001` | Member exists |
| `/fines` | external user/operator | `/fines M000001` | Member exists |
| `/report_issue` | external user/operator | `/report_issue M000001 LN000123 damaged` | Member exists, loan exists, loan belongs to member, status allows issue report |
| `/purchase_needs` | manager | `/purchase_needs` | Returns top purchase candidates |
| `/kpis` | manager | `/kpis` | Returns management KPI summary |

## Scenario 1: Book Search

Input fields:

- Search text: title, category, or author keyword.
- Optional language/category filter.

Validation:

- Search text must not be empty.
- Result must match title, category, or author.

Output:

- Matching titles.
- Available copy count.
- Category and language.
- Telegram response includes up to 5 matching books so the message stays readable.

## Scenario 2: Reserve Book

Input fields:

- member_id.
- book_id.

Validation:

- member_id exists.
- member status is active.
- membership is not expired.
- book_id exists.
- member does not already have a waiting/ready reservation for the same book.
- member has no serious unpaid fine balance.

Success response:

- Reservation tracking number.
- Queue position or ready message.

Error response:

- Clear reason and correction request.

## Scenario 3: Check Loan Status

Input fields:

- member_id.

Validation:

- member_id exists.

Output:

- Active loans.
- Overdue loans.
- Due dates.
- Book titles.

## Scenario 4: Report Lost or Damaged Book

Input fields:

- member_id.
- loan_id.
- issue_type: lost or damaged.

Validation:

- member_id exists.
- loan_id exists.
- loan belongs to member.
- loan is active or overdue.
- issue_type is valid.

Output:

- Tracking number.
- Review/fine estimate.
- Next step.

## Scenario 5: Check Fines

Input fields:

- member_id.

Validation:

- member_id exists.

Output:

- Total assessed fines.
- Paid amount.
- Outstanding amount.
- Fine details.

## Scenario 6: Manager KPI Request

Input:

- `/kpis`

Output:

- Total loans.
- Active loans.
- Overdue loans.
- Available copies.
- Fine balance.
- Waiting reservations.

## Scenario 7: Purchase Recommendation Request

Input:

- `/purchase_needs`

Output:

- Top books by purchase_need_score.
- Loan count.
- Reservation count.
- Available copies.

## Sample Dialogue

User: I want to reserve book B000027. My member ID is M000104.

Bot:

1. Checks member M000104 exists.
2. Checks membership status is active.
3. Checks unpaid fine balance.
4. Checks book B000027 exists.
5. Checks duplicate active reservations.

If valid:

Your reservation was accepted. Tracking number: RSV-20260708-104-027. The title has 2 available copies and your request has been recorded.

If invalid:

This reservation cannot be completed because your membership status is expired. Please renew your membership and try again.

## Technical Implementation

The Telegram bot uses long polling through the official Telegram Bot API. To run it:

1. Create a bot in Telegram using BotFather.
2. Copy the bot token.
3. Set the environment variable `TELEGRAM_BOT_TOKEN`.
4. Run `python telegram_bot.py`.

In Google Colab, use:

```python
import os
os.environ["TELEGRAM_BOT_TOKEN"] = "PASTE_TOKEN_HERE"
!python telegram_bot.py
```

For final submission, include the Telegram bot username or link in the report title page.
