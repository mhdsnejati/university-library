# University Library BI Project: ERD and Table Structure

## System Scope

This model supports a university library system used by three stakeholder groups:

- Manager: monitors borrowing demand, overdue items, fines, branch performance, and purchase needs.
- Analyst/operator: follows daily circulation, reservations, copy availability, member issues, and data quality.
- External user/member: searches books, checks availability, reserves titles, tracks loans, and reviews fines.

The design uses 12 tables. The main business events are loans, reservations, and fines. Book demand can be measured through loans and reservations, while purchase needs can be inferred from high demand, low available copies, and repeated overdue or lost-copy patterns.

## Conceptual ERD

```mermaid
erDiagram
    LIBRARY_BRANCH ||--o{ MEMBER : "home branch"
    LIBRARY_BRANCH ||--o{ LIBRARIAN : "employs"
    LIBRARY_BRANCH ||--o{ BOOK_COPY : "stores"

    PUBLISHER ||--o{ BOOK : "publishes"
    CATEGORY ||--o{ CATEGORY : "parent category"
    CATEGORY ||--o{ BOOK : "classifies"

    BOOK ||--o{ BOOK_AUTHOR : "has"
    AUTHOR ||--o{ BOOK_AUTHOR : "writes"
    BOOK ||--o{ BOOK_COPY : "has copies"

    MEMBER ||--o{ LOAN : "borrows"
    BOOK_COPY ||--o{ LOAN : "loaned as"
    LIBRARIAN ||--o{ LOAN : "processes checkout"
    LIBRARIAN ||--o{ LOAN : "processes return"

    MEMBER ||--o{ RESERVATION : "places"
    BOOK ||--o{ RESERVATION : "reserved title"
    LIBRARIAN ||--o{ RESERVATION : "handles"
    LOAN ||--o| RESERVATION : "fulfills"

    MEMBER ||--o{ FINE : "owes"
    LOAN ||--o{ FINE : "generates"
```

## Main Entities and Relationships

| Entity | Purpose | Key Relationships |
|---|---|---|
| LibraryBranch | Physical branch or campus library | Has many members, librarians, and book copies |
| Member | Student, faculty, staff, or public library user | Has many loans, reservations, and fines |
| Librarian | Operator, analyst, admin, or manager | Processes loans and handles reservations |
| Publisher | Book publisher information | Publishes many books |
| Category | Subject/category hierarchy | Classifies books and can have parent categories |
| Author | Author information | Connected to books through BookAuthor |
| Book | Bibliographic title-level record | Has authors, one category, one publisher, and many copies |
| BookAuthor | Bridge table for book-author many-to-many relationship | Links books and authors |
| BookCopy | Physical copy of a book | Belongs to one book and one branch; can be loaned |
| Loan | Borrowing transaction | Connects member, copy, checkout librarian, and return librarian |
| Reservation | Reservation request for a title | Connects member and book; may be fulfilled by a loan |
| Fine | Monetary penalty | Linked to member and usually to a loan |

## Table Structure

### 1. library_branch

| Column | Type | Key | Rules / Notes |
|---|---|---|---|
| branch_id | TEXT | PK | Example: BR001 |
| branch_name | TEXT |  | Required |
| city | TEXT |  | Required |
| address | TEXT |  | Required |
| phone | TEXT |  | Optional |
| opened_date | DATE |  | Must not be in the future for generated data |
| status | TEXT |  | active, closed, renovation |

### 2. member

| Column | Type | Key | Rules / Notes |
|---|---|---|---|
| member_id | TEXT | PK | Example: M000001 |
| home_branch_id | TEXT | FK | References library_branch.branch_id |
| full_name | TEXT |  | Required |
| email | TEXT | UNIQUE | Required, valid email format |
| phone | TEXT |  | Optional |
| member_type | TEXT |  | student, faculty, staff, public |
| department_or_program | TEXT |  | Optional for public members |
| join_date | DATE |  | Required |
| expiry_date | DATE |  | Must be after join_date |
| status | TEXT |  | active, suspended, expired |
| max_active_loans | INTEGER |  | Usually 3 to 10 depending on member_type |

### 3. librarian

| Column | Type | Key | Rules / Notes |
|---|---|---|---|
| librarian_id | TEXT | PK | Example: L001 |
| branch_id | TEXT | FK | References library_branch.branch_id |
| full_name | TEXT |  | Required |
| email | TEXT | UNIQUE | Required |
| role | TEXT |  | manager, analyst, circulation, admin |
| hire_date | DATE |  | Required |
| status | TEXT |  | active, inactive |

### 4. publisher

| Column | Type | Key | Rules / Notes |
|---|---|---|---|
| publisher_id | TEXT | PK | Example: PUB001 |
| publisher_name | TEXT | UNIQUE | Required |
| country | TEXT |  | Optional |
| website | TEXT |  | Optional |

### 5. category

| Column | Type | Key | Rules / Notes |
|---|---|---|---|
| category_id | TEXT | PK | Example: CAT001 |
| parent_category_id | TEXT | FK | Self-reference to category.category_id, nullable |
| category_name | TEXT |  | Required |
| shelf_code | TEXT | UNIQUE | Example: CS, MATH, MED |

### 6. author

| Column | Type | Key | Rules / Notes |
|---|---|---|---|
| author_id | TEXT | PK | Example: A0001 |
| full_name | TEXT |  | Required |
| nationality | TEXT |  | Optional |
| birth_year | INTEGER |  | Optional; realistic range only |

### 7. book

| Column | Type | Key | Rules / Notes |
|---|---|---|---|
| book_id | TEXT | PK | Example: B000001 |
| publisher_id | TEXT | FK | References publisher.publisher_id |
| category_id | TEXT | FK | References category.category_id |
| isbn | TEXT | UNIQUE | Required for most books |
| title | TEXT |  | Required |
| language | TEXT |  | Example: English, Persian, Arabic |
| publication_year | INTEGER |  | Must be realistic and not future year |
| edition | TEXT |  | Optional |
| page_count | INTEGER |  | Positive number |
| target_audience | TEXT |  | undergraduate, graduate, faculty, general |

### 8. book_author

| Column | Type | Key | Rules / Notes |
|---|---|---|---|
| book_id | TEXT | PK, FK | References book.book_id |
| author_id | TEXT | PK, FK | References author.author_id |
| author_order | INTEGER |  | 1 for first author, 2 for second, etc. |

### 9. book_copy

| Column | Type | Key | Rules / Notes |
|---|---|---|---|
| copy_id | TEXT | PK | Example: C000001 |
| book_id | TEXT | FK | References book.book_id |
| branch_id | TEXT | FK | References library_branch.branch_id |
| barcode | TEXT | UNIQUE | Required |
| acquisition_date | DATE |  | Required |
| purchase_price | DECIMAL |  | Non-negative |
| shelf_location | TEXT |  | Example: CS-A2-04 |
| condition_status | TEXT |  | new, good, worn, damaged, lost |
| availability_status | TEXT |  | available, on_loan, reserved, maintenance, lost, retired |
| is_reference_only | BOOLEAN |  | 1 means cannot be borrowed |

### 10. loan

| Column | Type | Key | Rules / Notes |
|---|---|---|---|
| loan_id | TEXT | PK | Example: LN000001 |
| member_id | TEXT | FK | References member.member_id |
| copy_id | TEXT | FK | References book_copy.copy_id |
| checkout_librarian_id | TEXT | FK | References librarian.librarian_id |
| checkin_librarian_id | TEXT | FK | Nullable until returned |
| checkout_date | DATE |  | Required |
| due_date | DATE |  | Must be after checkout_date |
| return_date | DATE |  | Nullable; must be after checkout_date |
| renewal_count | INTEGER |  | 0 to 3 |
| loan_status | TEXT |  | active, returned, overdue, lost |

### 11. reservation

| Column | Type | Key | Rules / Notes |
|---|---|---|---|
| reservation_id | TEXT | PK | Example: R000001 |
| member_id | TEXT | FK | References member.member_id |
| book_id | TEXT | FK | References book.book_id |
| handled_by_librarian_id | TEXT | FK | Nullable for self-service |
| fulfilled_loan_id | TEXT | FK | References loan.loan_id, nullable |
| reservation_date | DATE |  | Required |
| expiry_date | DATE |  | Must be after reservation_date |
| reservation_status | TEXT |  | waiting, ready_for_pickup, fulfilled, cancelled, expired |
| queue_position | INTEGER |  | Positive while waiting |

### 12. fine

| Column | Type | Key | Rules / Notes |
|---|---|---|---|
| fine_id | TEXT | PK | Example: F000001 |
| member_id | TEXT | FK | References member.member_id |
| loan_id | TEXT | FK | References loan.loan_id |
| assessed_date | DATE |  | Required |
| fine_type | TEXT |  | late_return, lost_item, damage, processing |
| amount | DECIMAL |  | Non-negative |
| paid_amount | DECIMAL |  | Between 0 and amount |
| fine_status | TEXT |  | unpaid, partially_paid, paid, waived |
| payment_date | DATE |  | Required only when paid or partially paid |
| notes | TEXT |  | Optional |

## Business Rules and Data Constraints

1. A member must belong to one home branch.
2. A physical book copy belongs to exactly one book and one branch.
3. A book can have one or more authors.
4. A loan is created for a physical copy, not only for a title.
5. A reservation is created for a book title, because the exact copy may not be known when the user reserves it.
6. Reference-only copies cannot be borrowed.
7. A copy with availability_status = on_loan should have one active or overdue loan.
8. due_date must be after checkout_date.
9. return_date must be empty for active, overdue, or lost loans.
10. A fine amount cannot be negative, and paid_amount cannot exceed amount.
11. Suspended or expired members cannot create new loans or reservations.
12. A member should not exceed max_active_loans.
13. A reservation can be fulfilled only if it links to a valid loan for the same member and book.
14. queue_position should be filled only for waiting reservations.
15. Books with high reservations and low available copies should be flagged as purchase needs.

## Data Source and Quality Plan

For this course submission, the dataset is valid assumed project data generated from the ERD and business rules. It is not random text: every table follows primary keys, foreign keys, date rules, loan rules, reservation rules, and fine rules.

If real university library exports become available later, they can replace the assumed CSV files without changing the ERD. Real member, loan, reservation, and fine records should be anonymized before sharing.

## Minimum Assumed Data Coverage

| Table | Project Coverage Target | Quality Rule |
|---|---:|---|
| library_branch | 3+ branches | Each member, librarian, and copy links to a valid branch |
| member | 300+ members | Expiry date is after join date; status is active, suspended, or expired |
| librarian | 12+ librarians | Each operator links to a valid branch and role |
| publisher | 25+ publishers | Each book links to a valid publisher |
| category | 15+ categories | Each book links to a valid subject category |
| author | 150+ authors | Each book has at least one author |
| book | 250+ titles | ISBN, title, language, year, pages, and audience are filled |
| book_author | 300+ links | Supports books with one or more authors |
| book_copy | 600+ copies | Each copy links to one title and one branch |
| loan | 1,500+ loans | Dates, statuses, returns, and overdue logic are consistent |
| reservation | 400+ reservations | Waiting reservations have queue positions |
| fine | 150+ fines | Amounts are non-negative and payment status is consistent |

## Data Quality Controls

1. Every foreign key must match an existing primary key.
2. Dates must be logical: due_date after checkout_date, return_date after checkout_date, expiry_date after reservation_date.
3. A returned loan must have a return_date; active, overdue, and lost loans must not.
4. Waiting reservations must have queue_position; non-waiting reservations do not require it.
5. paid_amount must never exceed amount.
6. Reference-only copies should not be selected for normal borrowing.
7. High reservation demand plus low copy availability creates a defensible purchase-need signal.

## Dashboard-Ready Measures

| KPI / Measure | Source Tables | Definition |
|---|---|---|
| Total loans | loan | Count of loan_id |
| Active loans | loan | loan_status = active |
| Overdue loans | loan | loan_status = overdue or due_date before current date with no return_date |
| Overdue rate | loan | Overdue loans / total active and overdue loans |
| Available copies | book_copy | availability_status = available |
| Reservation demand | reservation | Count of reservations by book, category, or branch |
| Fine balance | fine | Sum(amount - paid_amount) |
| Paid fines | fine | Sum(paid_amount) |
| Most borrowed books | loan, book_copy, book | Count of loans grouped by book |
| Purchase need score | book, book_copy, loan, reservation | High reservations + high loans + low available copies |

## Chatbot Validation Hooks

| Scenario | Tables Used | Validation |
|---|---|---|
| Search book | book, author, category, book_copy | Match title/author/category and show available copies |
| Reserve book | member, book, book_copy, reservation, fine | Check active membership, unpaid fines, existing reservation, available or reservable title |
| Check loan status | member, loan, book_copy, book | Verify member ID and list active, overdue, and returned loans |
| Report lost/damaged copy | member, loan, book_copy, fine | Confirm active loan, copy identity, and create a fine record or review request |
| Ask about fines | member, fine, loan | Verify member ID and summarize unpaid/paid fines |
