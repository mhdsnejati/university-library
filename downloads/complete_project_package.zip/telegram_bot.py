from __future__ import annotations

import json
import os
import time
import traceback
import urllib.parse
import urllib.request

import library_chatbot as core


TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
API_BASE = f"https://api.telegram.org/bot{TOKEN}"


def api_call(method, payload=None):
    if not TOKEN:
        raise RuntimeError("Set TELEGRAM_BOT_TOKEN before running this bot.")
    data = urllib.parse.urlencode(payload or {}).encode("utf-8")
    with urllib.request.urlopen(f"{API_BASE}/{method}", data=data, timeout=40) as response:
        return json.loads(response.read().decode("utf-8"))


def send_message(chat_id, text):
    return api_call(
        "sendMessage",
        {
            "chat_id": chat_id,
            "text": text[:3900],
            "parse_mode": "HTML",
            "disable_web_page_preview": True,
        },
    )


def format_search(result):
    if not result["ok"]:
        return result["message"]
    lines = ["<b>Search results</b>"]
    for row in result["results"][:5]:
        lines.append(
            f"{row['book_id']} | {row['title']}\n"
            f"Category: {row['category']} | Language: {row['language']} | Available: {row['available_copies']}"
        )
    return "\n\n".join(lines)


def format_loans(result):
    if not result["ok"]:
        return result["message"]
    if not result["open_loans"]:
        return f"No active, overdue, or lost loans found for {result['member_id']}."
    lines = [f"<b>Open loans for {result['member_id']}</b>"]
    for row in result["open_loans"][:10]:
        lines.append(f"{row['loan_id']} | {row['status']} | Due: {row['due_date']}\n{row['title']}")
    return "\n\n".join(lines)


def format_fines(result):
    if not result["ok"]:
        return result["message"]
    return (
        f"<b>Fine summary for {result['member_id']}</b>\n"
        f"Assessed: {result['assessed']:.2f}\n"
        f"Paid: {result['paid']:.2f}\n"
        f"Outstanding: {result['outstanding']:.2f}\n"
        f"Fine records: {result['fine_count']}"
    )


def format_kpis():
    result = core.load_kpi_summary()
    if not result["ok"]:
        return result["message"]
    kpis = result["kpis"]
    return (
        "<b>Manager KPI Summary</b>\n"
        f"Total loans: {kpis.get('total_loans', '-')}\n"
        f"Active loans: {kpis.get('active_loans', '-')}\n"
        f"Overdue loans: {kpis.get('overdue_loans', '-')}\n"
        f"Overdue rate: {kpis.get('overdue_rate_percent', '-')}%\n"
        f"Available copies: {kpis.get('available_copies', '-')}\n"
        f"Waiting reservations: {kpis.get('waiting_reservations', '-')}\n"
        f"Fine balance: {kpis.get('fine_balance', '-')}"
    )


def format_purchase_needs():
    result = core.purchase_recommendations(5)
    if not result["ok"]:
        return result["message"]
    lines = ["<b>Top Purchase Recommendations</b>"]
    for row in result["recommendations"]:
        lines.append(
            f"{row['book_id']} | {row['title']}\n"
            f"Category: {row['category_name']} | Score: {row['purchase_need_score']} | "
            f"Loans: {row['loan_count']} | Reservations: {row['reservation_count']} | Available: {row['available_copies']}"
        )
    return "\n\n".join(lines)


def help_text():
    return (
        "<b>Central University Library Bot</b>\n"
        "Commands:\n"
        "/search keyword\n"
        "/reserve MEMBER_ID BOOK_ID\n"
        "/loans MEMBER_ID\n"
        "/fines MEMBER_ID\n"
        "/report_issue MEMBER_ID LOAN_ID lost|damaged\n"
        "/kpis\n"
        "/purchase_needs"
    )


def handle_message(data, text):
    text = (text or "").strip()
    if not text or text == "/start" or text == "/help":
        return help_text()

    parts = text.split()
    command = parts[0].lower()

    if command == "/search":
        if len(parts) < 2:
            return "Please write a search term. Example: /search database"
        return format_search(core.search_books(data, " ".join(parts[1:])))

    if command == "/reserve":
        if len(parts) != 3:
            return "Use this format: /reserve MEMBER_ID BOOK_ID"
        result = core.reserve_book(data, parts[1], parts[2])
        return result["message"]

    if command == "/loans":
        if len(parts) != 2:
            return "Use this format: /loans MEMBER_ID"
        return format_loans(core.check_loan_status(data, parts[1]))

    if command == "/fines":
        if len(parts) != 2:
            return "Use this format: /fines MEMBER_ID"
        return format_fines(core.check_fines(data, parts[1]))

    if command == "/report_issue":
        if len(parts) != 4:
            return "Use this format: /report_issue MEMBER_ID LOAN_ID lost|damaged"
        result = core.report_lost_or_damaged(data, parts[1], parts[2], parts[3].lower())
        return result["message"]

    if command == "/kpis":
        return format_kpis()

    if command == "/purchase_needs":
        return format_purchase_needs()

    return "Unknown command.\n\n" + help_text()


def main():
    data = core.load_data()
    offset = 0
    print("Telegram bot is running. Press Ctrl+C to stop.")
    while True:
        try:
            response = api_call("getUpdates", {"offset": offset, "timeout": 30})
            for update in response.get("result", []):
                offset = update["update_id"] + 1
                message = update.get("message") or update.get("edited_message")
                if not message:
                    continue
                chat_id = message["chat"]["id"]
                reply = handle_message(data, message.get("text", ""))
                send_message(chat_id, reply)
        except KeyboardInterrupt:
            print("Stopped.")
            return
        except Exception:
            traceback.print_exc()
            time.sleep(5)


if __name__ == "__main__":
    main()
