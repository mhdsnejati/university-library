# Central University Library Management System

Complete BI course project for Topic #11: University Library.

- Student: Mohadese Nejati
- Course: Business Intelligence
- University: Sharif University
- Professor: Dr. Ghodosi
- Delivery date: 20 Mordad
- Dataset: near-real assumed operational data: a privacy-safe course dataset designed to behave like a real university library export while preserving complete ERD consistency

## Generated Deliverables

- `data/`: normalized CSV tables matching the ERD and SQL schema.
- `db/university_library.db`: SQLite database created from `schema.sql`.
- `outputs/`: Looker Studio friendly CSV exports and KPI summary.
- `dashboard/dashboard_preview.html`: local dashboard preview.
- `report/final_report.md`: final report text following the required template.
- `report/final_report.html`: browser-readable report.
- `dashboard_blueprint.md`: exact Looker Studio page/chart plan.
- `chatbot_design.md`: Telegram chatbot roles, scenarios, validation rules, and sample dialogue.
- `library_chatbot.py`: runnable chatbot validation logic.
- `telegram_bot.py`: Telegram Bot API wrapper.
- `telegram_deployment.md`: Telegram setup guide.
- `colab_runbook.md`: step-by-step Google Colab instructions.

## Dataset Size

| Table | Rows |
|---|---:|
| library_branch | 4 |
| member | 520 |
| librarian | 18 |
| publisher | 32 |
| category | 18 |
| author | 180 |
| book | 320 |
| book_author | 456 |
| book_copy | 1,024 |
| loan | 2,200 |
| reservation | 650 |
| fine | 408 |

## Build Again

Run:

```bash
python build_project.py
```

In Google Colab, upload this folder and run the same command from inside the folder.

## Looker Studio

Use the CSV files in `outputs/` for the dashboard. They are easier than connecting all 12 normalized tables directly.

Recommended production files:

- `outputs/looker_loan_detail.csv`
- `outputs/looker_reservation_detail.csv`
- `outputs/looker_fine_detail.csv`
- `outputs/looker_book_demand.csv`
- `outputs/kpi_summary.csv`

## Telegram

Run:

```bash
python library_chatbot.py
```

For Telegram deployment, create a bot with BotFather, set `TELEGRAM_BOT_TOKEN`, then run:

```bash
python telegram_bot.py
```
