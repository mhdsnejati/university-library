# Google Colab Runbook

Project: Central University Library Management System
Student: Mohadese Nejati

## Step 1: Upload the Project Folder

Upload the full `university_library_bi` folder to Google Drive, then open Google Colab.

## Step 2: Mount Google Drive

```python
from google.colab import drive
drive.mount('/content/drive')
```

## Step 3: Go to the Project Folder

Change the path if your folder is somewhere else.

```python
%cd /content/drive/MyDrive/university_library_bi
```

## Step 4: Build the Dataset and Deliverables

```python
!python build_project.py
```

## Step 5: Check the Generated Files

```python
import pandas as pd
pd.read_csv('outputs/kpi_summary.csv')
```

Open the local dashboard preview:

```python
from IPython.display import HTML
HTML(filename='dashboard/dashboard_preview.html')
```

## Step 6: Test the Chatbot Logic

```python
import library_chatbot as bot
data = bot.load_data()
bot.search_books(data, 'database')
```

```python
bot.reserve_book(data, 'M000001', 'B000001')
```

Manager checks:

```python
bot.load_kpi_summary()
bot.purchase_recommendations(5)
```

## Step 7: Use the Data in Looker Studio

Upload these CSV files to Google Sheets:

- `outputs/looker_loan_detail.csv`
- `outputs/looker_reservation_detail.csv`
- `outputs/looker_fine_detail.csv`
- `outputs/looker_book_demand.csv`
- `outputs/kpi_summary.csv`

Then connect those Google Sheets to Looker Studio and build the three pages described in `dashboard_blueprint.md`.

Required Looker pages:

1. Manager page.
2. Analyst/operator page.
3. External user/member page.

Required filters:

- Date range.
- Branch.
- Category.
- Member type.
- Loan status.

## Step 8: Run the Telegram Bot

Create a Telegram bot with BotFather, copy the token, then run:

```python
import os
os.environ["TELEGRAM_BOT_TOKEN"] = "PASTE_YOUR_BOTFATHER_TOKEN_HERE"
!python telegram_bot.py
```

Keep the Colab cell running while you test these Telegram commands:

```text
/start
/search database
/reserve M000001 B000001
/loans M000001
/fines M000001
/kpis
/purchase_needs
```

## Step 9: Final Submission Checklist

- Replace placeholder dashboard link in `report/final_report.md`.
- Replace placeholder Telegram bot link/user name in `report/final_report.md`.
- Share Looker Studio access with the instructor.
- Send the final report, dashboard link, Telegram bot link, and access details by 20 Mordad.
