from __future__ import annotations

import csv
import html
import re
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent
OUTPUT_HTML = ROOT / "complete_project.html"
OUTPUT_ZIP = ROOT / "complete_project_package.zip"


TEXT_DOCS = [
    ("Looker Studio Build Guide", ROOT / "dashboard_blueprint.md"),
    ("Telegram Chatbot Design", ROOT / "chatbot_design.md"),
    ("Telegram Deployment Guide", ROOT / "telegram_deployment.md"),
    ("Google Colab Runbook", ROOT / "colab_runbook.md"),
    ("ERD and Table Structure", ROOT / "erd_table_structure.md"),
    ("Data Authenticity Plan", ROOT / "real_data_source_plan.md"),
    ("README", ROOT / "README.md"),
]


PACKAGE_PATTERNS = [
    "README.md",
    "complete_project_summary.md",
    "schema.sql",
    "erd_table_structure.md",
    "real_data_source_plan.md",
    "dashboard_blueprint.md",
    "chatbot_design.md",
    "telegram_deployment.md",
    "colab_runbook.md",
    "build_project.py",
    "library_chatbot.py",
    "telegram_bot.py",
    "make_single_file.py",
    "data/*.csv",
    "outputs/*.csv",
    "outputs/*.json",
    "report/*.md",
    "report/*.html",
    "dashboard/*.html",
    "db/*.db",
]


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def markdown_inline(text: str) -> str:
    text = html.escape(text)
    text = re.sub(r"`([^`]+)`", r"<code>\1</code>", text)
    text = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", text)
    return text


def markdown_to_html(markdown: str) -> str:
    lines = markdown.splitlines()
    out: list[str] = []
    in_list = False
    in_code = False
    code_lines: list[str] = []
    table_lines: list[str] = []

    def flush_list() -> None:
        nonlocal in_list
        if in_list:
            out.append("</ul>")
            in_list = False

    def flush_code() -> None:
        nonlocal in_code, code_lines
        if in_code:
            out.append("<pre><code>" + html.escape("\n".join(code_lines)) + "</code></pre>")
            code_lines = []
            in_code = False

    def flush_table() -> None:
        nonlocal table_lines
        if not table_lines:
            return
        out.append("<div class=\"table-scroll\"><table>")
        for idx, row in enumerate(table_lines):
            cells = [cell.strip() for cell in row.strip("|").split("|")]
            if idx == 1 and all(set(cell.replace(":", "")) <= {"-"} for cell in cells):
                continue
            tag = "th" if idx == 0 else "td"
            out.append("<tr>" + "".join(f"<{tag}>{markdown_inline(cell)}</{tag}>" for cell in cells) + "</tr>")
        out.append("</table></div>")
        table_lines = []

    for line in lines:
        if line.startswith("```"):
            flush_table()
            flush_list()
            if in_code:
                flush_code()
            else:
                in_code = True
            continue
        if in_code:
            code_lines.append(line)
            continue
        if line.startswith("|") and line.endswith("|"):
            flush_list()
            table_lines.append(line)
            continue
        flush_table()
        if line.startswith("# "):
            flush_list()
            out.append(f"<h2>{markdown_inline(line[2:])}</h2>")
        elif line.startswith("## "):
            flush_list()
            out.append(f"<h3>{markdown_inline(line[3:])}</h3>")
        elif line.startswith("### "):
            flush_list()
            out.append(f"<h4>{markdown_inline(line[4:])}</h4>")
        elif line.startswith("- "):
            if not in_list:
                out.append("<ul>")
                in_list = True
            out.append(f"<li>{markdown_inline(line[2:])}</li>")
        elif re.match(r"^\d+\. ", line):
            flush_list()
            out.append(f"<p>{markdown_inline(line)}</p>")
        elif line.strip():
            flush_list()
            out.append(f"<p>{markdown_inline(line)}</p>")
        else:
            flush_list()
    flush_code()
    flush_table()
    flush_list()
    return "\n".join(out)


def csv_counts() -> list[dict[str, str]]:
    rows = []
    for path in sorted((ROOT / "data").glob("*.csv")):
        with path.open(newline="", encoding="utf-8") as handle:
            count = sum(1 for _ in csv.reader(handle)) - 1
        rows.append({"file": f"data/{path.name}", "rows": f"{count:,}"})
    for path in sorted((ROOT / "outputs").glob("*.csv")):
        with path.open(newline="", encoding="utf-8") as handle:
            count = sum(1 for _ in csv.reader(handle)) - 1
        rows.append({"file": f"outputs/{path.name}", "rows": f"{count:,}"})
    return rows


def table_from_dicts(rows: list[dict[str, str]]) -> str:
    if not rows:
        return ""
    columns = list(rows[0].keys())
    body = []
    for row in rows:
        body.append("<tr>" + "".join(f"<td>{html.escape(row[col])}</td>" for col in columns) + "</tr>")
    head = "".join(f"<th>{html.escape(col.title())}</th>" for col in columns)
    return f"<div class=\"table-scroll\"><table><tr>{head}</tr>{''.join(body)}</table></div>"


def iframe_srcdoc(raw_html: str, title: str) -> str:
    return (
        f"<iframe title=\"{html.escape(title)}\" "
        f"srcdoc=\"{html.escape(raw_html, quote=True)}\"></iframe>"
    )


def create_complete_html() -> None:
    report_html = read_text(ROOT / "report" / "final_report.html")
    dashboard_html = read_text(ROOT / "dashboard" / "dashboard_preview.html")
    docs_html = "\n".join(
        f"<article class=\"doc-card\"><h2>{html.escape(title)}</h2>{markdown_to_html(read_text(path))}</article>"
        for title, path in TEXT_DOCS
    )
    counts_html = table_from_dicts(csv_counts())

    page = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Complete Project - Central University Library Management System</title>
  <style>
    :root {{
      --ink:#17202a; --muted:#5d6b7a; --line:#d7dde5; --paper:#ffffff; --bg:#eef2f5;
      --navy:#101928; --blue:#2563eb; --green:#008a67; --amber:#c77913;
    }}
    * {{ box-sizing:border-box; }}
    html {{ scroll-behavior:smooth; }}
    body {{ margin:0; font-family:Arial, sans-serif; background:var(--bg); color:var(--ink); line-height:1.55; }}
    header {{ background:var(--navy); color:white; padding:28px 34px; }}
    header h1 {{ margin:0 0 8px; font-size:30px; letter-spacing:0; }}
    header p {{ margin:0; color:#d7dee8; max-width:1020px; }}
    nav {{ position:sticky; top:0; z-index:10; display:flex; flex-wrap:wrap; gap:8px; padding:12px 28px; background:white; border-bottom:1px solid var(--line); }}
    nav a {{ text-decoration:none; color:var(--ink); border:1px solid var(--line); border-radius:6px; padding:7px 10px; font-size:14px; background:#fbfcfd; }}
    main {{ max-width:1240px; margin:0 auto; padding:24px 18px 54px; }}
    section, .doc-card {{ background:var(--paper); border:1px solid var(--line); border-radius:8px; padding:18px; margin:0 0 18px; box-shadow:0 1px 2px rgba(16,24,40,.04); }}
    h2 {{ margin:0 0 10px; font-size:23px; }}
    h3 {{ margin:20px 0 8px; font-size:18px; }}
    h4 {{ margin:16px 0 6px; font-size:15px; }}
    p {{ margin:8px 0; }}
    code {{ background:#edf1f5; padding:2px 4px; border-radius:4px; }}
    pre {{ background:#101928; color:#f8fafc; padding:12px; border-radius:8px; overflow:auto; }}
    iframe {{ width:100%; height:760px; border:1px solid var(--line); border-radius:8px; background:white; }}
    .two {{ display:grid; grid-template-columns:1fr 1fr; gap:14px; }}
    .callout {{ border-left:4px solid var(--blue); background:#f8fbff; padding:13px; border-radius:6px; }}
    .callout.green {{ border-left-color:var(--green); }}
    .callout.amber {{ border-left-color:var(--amber); }}
    .table-scroll {{ overflow:auto; }}
    table {{ border-collapse:collapse; width:100%; font-size:13px; margin:10px 0; }}
    th, td {{ border:1px solid var(--line); padding:8px; text-align:left; vertical-align:top; }}
    th {{ background:#edf1f5; }}
    .file-note {{ color:var(--muted); font-size:13px; }}
    @media (max-width:800px) {{
      header {{ padding:22px 18px; }}
      nav {{ padding:10px 14px; }}
      .two {{ grid-template-columns:1fr; }}
      iframe {{ height:620px; }}
    }}
  </style>
</head>
<body>
  <header>
    <h1>Complete Project: Central University Library Management System</h1>
    <p>One-file viewer for Mohadese Nejati's Business Intelligence project at Sharif University for Dr. Ghodosi. This page combines the final report, dashboard preview, Looker Studio instructions, Telegram chatbot guide, Colab runbook, ERD, and data checklist.</p>
  </header>
  <nav>
    <a href="#quick">How To Use</a>
    <a href="#dashboard">Dashboard</a>
    <a href="#report">Report</a>
    <a href="#data">Data</a>
    <a href="#docs">Guides</a>
  </nav>
  <main>
    <section id="quick">
      <h2>How To Use This One File</h2>
      <div class="two">
        <div class="callout green">
          <h3>To See It Here</h3>
          <p>Open <code>complete_project.html</code> in a browser. No Python is needed for viewing this combined project page.</p>
          <p class="file-note">Location: <code>C:\\Users\\Asus Zenbook\\Documents\\AP\\university_library_bi\\complete_project.html</code></p>
        </div>
        <div class="callout">
          <h3>To Submit or Move Everything</h3>
          <p>Use <code>complete_project_package.zip</code>. It contains the report, dashboard, data, Looker exports, chatbot, Telegram files, and database.</p>
          <p class="file-note">Location: <code>C:\\Users\\Asus Zenbook\\Documents\\AP\\university_library_bi\\complete_project_package.zip</code></p>
        </div>
      </div>
      <div class="callout amber">
        <h3>What Still Needs Your Account</h3>
        <p>You still need to publish the Looker Studio dashboard using your Google account and create a Telegram bot token with BotFather. Those two links should then be added to the report title page.</p>
      </div>
    </section>

    <section id="dashboard">
      <h2>Dashboard Preview</h2>
      <p>This is the local professional preview. Recreate it in Looker Studio using the guide below.</p>
      {iframe_srcdoc(dashboard_html, "Dashboard Preview")}
    </section>

    <section id="report">
      <h2>Final Report</h2>
      <p>This is the complete English report with your name, university, professor, delivery date, analysis, Looker plan, and Telegram chatbot section.</p>
      {iframe_srcdoc(report_html, "Final Report")}
    </section>

    <section id="data">
      <h2>Data and Looker Exports</h2>
      <p>The normalized CSV files and Looker-ready exports are included in the zip package and remain available in the project folder.</p>
      {counts_html}
    </section>

    <section id="docs">
      <h2>All Guides and Documentation</h2>
      {docs_html}
    </section>
  </main>
</body>
</html>"""
    OUTPUT_HTML.write_text(page, encoding="utf-8")


def create_zip() -> None:
    if OUTPUT_ZIP.exists():
        OUTPUT_ZIP.unlink()
    files: list[Path] = []
    for pattern in PACKAGE_PATTERNS:
        files.extend(path for path in ROOT.glob(pattern) if path.is_file())
    files.append(OUTPUT_HTML)
    unique_files = sorted(set(files), key=lambda path: str(path.relative_to(ROOT)))
    with zipfile.ZipFile(OUTPUT_ZIP, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in unique_files:
            archive.write(path, path.relative_to(ROOT))


def main() -> None:
    create_complete_html()
    create_zip()
    print(f"Created {OUTPUT_HTML}")
    print(f"Created {OUTPUT_ZIP}")


if __name__ == "__main__":
    main()
