# Central University Library Management System

## 1. Title Page

- Course: Business Intelligence
- Topic: Topic #11 - University Library
- Student: Mohadese Nejati
- University: Sharif University
- Professor: Dr. Ghodosi
- Delivery date: 20 Mordad
- Report language: English
- Looker Studio dashboard link: To be added after publishing
- Telegram chatbot link/user name: To be added after publishing

## 2. Executive Summary

This project designs and analyzes a professional BI solution for the Central University Library Management System. The system manages members, books, physical copies, loans, reservations, fines, branches, librarians, publishers, authors, and categories. The management problem is to improve book availability, reduce overdue risk, identify purchase needs, monitor branch performance, and provide a reliable member-facing service channel.

The dataset is near-real assumed operational data: a privacy-safe course dataset designed to behave like a real university library export while preserving complete ERD consistency. It contains 2,200 loan records, 650 reservation records, 1,024 physical copies, 320 books, and 520 members. The dashboard shows 2,200 total loans, 15 currently overdue loans, an overdue rate of 38.46% among open loans, 889 available copies, and an outstanding fine balance of 2,349.69.

Key findings:

- Purchase decisions should prioritize high-demand titles with repeated reservations and low available copies.
- Central Library has the highest loan volume with 699 loans, so staffing and copy allocation should be reviewed there first.
- Mathematics has the largest overdue concentration among current overdue categories, with 3 open overdue loans.
- Student members generate the highest loan volume with 1,496 loans, so communication and borrowing rules should be optimized for this user group.
- The Telegram chatbot should reduce operator workload by validating member IDs, book IDs, reservation rules, loan status, and fine balances before creating a request.

## 3. Introduction of the System and Stakeholders

The Central University Library Management System supports borrowing, reservation, inventory control, purchase planning, and fine management for a university environment. The project is designed for three stakeholder groups:

- Manager: needs strategic KPIs such as demand, overdue rate, fine balance, purchase needs, branch performance, and service quality.
- Analyst/operator: needs operational reports on active loans, overdue members, reservation queues, copy status, staff workload, and data quality.
- External user/member: needs book search, availability status, reservation status, active loans, due dates, and fine summaries.

## 4. Main Processes and Business Rules

Main processes:

1. Member registration and membership status control.
2. Book cataloging and physical copy inventory.
3. Loan checkout and return.
4. Reservation placement, queue management, and fulfillment.
5. Fine assessment and payment tracking.
6. Purchase-need analysis based on demand and availability.
7. Telegram chatbot request intake and validation.

Important rules:

- A member must be active to borrow or reserve books.
- A loan is created for a physical copy, while a reservation is created for a title.
- A reference-only copy cannot be borrowed.
- due_date must be after checkout_date.
- A returned loan must have a return_date.
- Waiting reservations must have a queue position.
- paid_amount cannot be greater than amount.
- The chatbot must reject incomplete, illogical, or inconsistent requests and explain the correction needed.

## 5. Data Model: Entities, Attributes, Keys, Relationships, and ERD

The model has 12 entities: LibraryBranch, Member, Librarian, Publisher, Category, Author, Book, BookAuthor, BookCopy, Loan, Reservation, and Fine.

Primary relationships:

- One branch has many members, librarians, and book copies.
- One publisher publishes many books.
- One category classifies many books.
- Books and authors have a many-to-many relationship through BookAuthor.
- One book has many physical copies.
- One member has many loans, reservations, and fines.
- One loan is linked to one member and one physical copy.
- One reservation is linked to one member and one book title.
- One fine is linked to one member and one loan.

The complete ERD and full table dictionary are in `erd_table_structure.md`.

## 6. Data Generation Method and Quality Control

The data was generated as a close-to-real assumed dataset for the course project. It is designed to behave like a real library export while avoiding private personal information. The generation uses fixed business rules, deterministic IDs, realistic date ranges, realistic status distributions, and referential integrity checks.

Data volume:

| table | rows |
| --- | --- |
| library_branch | 4 |
| member | 520 |
| librarian | 18 |
| publisher | 32 |
| category | 18 |
| author | 180 |
| book | 320 |
| book_author | 456 |
| book_copy | 1024 |
| loan | 2200 |
| reservation | 650 |
| fine | 408 |

Quality controls:

- All primary keys are unique.
- All foreign keys point to valid records.
- Dates follow the correct sequence.
- Loan status matches return_date logic.
- Waiting reservations have queue positions.
- Fine payment amounts do not exceed assessed amounts.
- Dashboard outputs are calculated from the generated database, not manually typed.
- Looker-ready exports are generated from joined analytical views, so the dashboard can be built without manually joining all 12 tables.

## 7. Looker Studio Dashboard Description

The Looker Studio dashboard should have three professional pages: Manager, Analyst/Operator, and External User. The recommended data sources are `looker_loan_detail.csv`, `looker_reservation_detail.csv`, `looker_fine_detail.csv`, `looker_book_demand.csv`, and `kpi_summary.csv`.

Manager page:

- KPI cards: total loans, overdue rate, available copies, outstanding fine balance.
- Time trend: monthly loans.
- Ranking table: purchase-need score by book.
- Bar chart: loans by branch.
- Donut chart: reservation status.
- Management analysis text box: recommended purchase and branch actions.

Analyst/operator page:

- KPI cards: active loans, overdue loans, waiting reservations.
- Bar chart: overdue loans by category.
- Table: active or overdue loans with member type, book, due date, and branch.
- Bar chart: processed loans by librarian.
- Filter controls: date range, branch, category, member type, loan status.
- Data-quality table: suspicious or inconsistent records to investigate.

External user/member page:

- Search-style table: book availability by title/category.
- KPI card: available copies.
- Table: sample member loan status.
- Table: sample member unpaid fines.
- Filter controls: category, language, audience, availability status.
- Member guidance panel: what to do if a title is unavailable or a fine is unpaid.

Every chart should include title, unit of measurement, and a one-line explanation.

## 8. Reports Needed by Each Role

Manager reports:

- Purchase needs by title and category.
- Monthly borrowing trend.
- Branch performance and copy availability.
- Fine balance and payment trend.
- High-risk categories for overdue monitoring.

Analyst/operator reports:

- Active and overdue loans.
- Reservation queue and ready-for-pickup list.
- Copy condition and maintenance list.
- Librarian checkout workload.
- Member accounts blocked by expired membership, suspension, or unpaid fines.

External user reports:

- Available copies by book.
- Reservation status.
- Active loans and due dates.
- Unpaid fine summary.
- Lost/damaged book request tracking.

## 9. Telegram Chatbot Design

Roles:

- Manager: asks for KPIs and purchase recommendations.
- Analyst/operator: checks member/copy status and validates operational entries.
- External user/member: searches, reserves, checks loans, and checks fines.

Required scenarios:

1. Search for a book by title, author, or category.
2. Reserve a book after checking membership and inventory.
3. Check active and overdue loan status.
4. Report a lost or damaged book.
5. Ask about unpaid fines.
6. Manager asks for purchase-need recommendations.
7. Analyst checks whether an entered member/book/loan combination is valid.

Validation rules:

- Member ID must exist.
- Member must be active for new borrowing/reservation.
- Book ID must exist.
- Duplicate active reservations should be rejected.
- Suspended or expired members should receive a correction message.
- Fine amounts and dates must be logical.
- The bot must return a tracking number or clear summary after each valid request.

The detailed chatbot design is in `chatbot_design.md`, the core validation logic is in `library_chatbot.py`, and the Telegram wrapper is in `telegram_bot.py`.

## 10. Final Analysis, Limitations, and Suggestions

Top borrowed books:

| title | category_name | loans |
| --- | --- | --- |
| Operations Management: Case Studies and Practice 23 | Management | 24 |
| Data Mining: A Modern Approach 314 | Computer Science | 20 |
| Development Economics: Methods for Researchers 38 | Economics | 20 |
| Numerical Methods: An Applied Introduction 251 | Mathematics | 20 |
| Ecology: A Modern Approach 244 | Biology | 19 |

Highest purchase-need candidates:

| title | category_name | loan_count | reservation_count | available_copies | purchase_need_score |
| --- | --- | --- | --- | --- | --- |
| Strategic Management: Methods for Researchers 282 | Management | 19 | 8 | 5 | 20.55 |
| Strategic Management: An Applied Introduction 106 | Management | 17 | 8 | 5 | 19.45 |
| Operations Management: Case Studies and Practice 23 | Management | 24 | 5 | 4 | 18.2 |
| Linear Algebra: Case Studies and Practice 6 | Mathematics | 17 | 8 | 6 | 17.95 |
| Data Mining: A Modern Approach 314 | Computer Science | 20 | 5 | 3 | 17.5 |

Management interpretation:

- Purchase recommendations: prioritize the top purchase-need titles because they combine high borrowing demand, reservation pressure, and limited availability.
- Overdue risk: focus reminders on Mathematics and other categories with concentrated overdue loans.
- Branch performance: compare branch workload before assigning staff or transferring copies; Central Library currently carries the highest loan volume.
- Member behavior: Student users are the largest borrowing segment, so policies, reminders, and chatbot examples should be optimized for them.
- Service improvement: use the Telegram chatbot as the first validation layer for reservations, loan checks, lost/damaged reports, and fine inquiries.

Limitations:

- The dataset is close-to-real assumed course data, not an official Sharif University library export.
- Personal data is privacy-safe project data.
- Looker Studio must be connected through Google Sheets or uploaded CSV files using the provided exports.
- Telegram deployment requires creating a bot token with BotFather and hosting the script in Colab, a server, or another always-on environment.

Suggestions:

- Add live integration with the real university library management system.
- Add automatic overdue reminders.
- Use reservation demand to create purchase orders.
- Add branch-level inventory transfer recommendations.
- Add a member-facing Telegram chatbot link inside the library website or student portal.
