PRAGMA foreign_keys = ON;

CREATE TABLE library_branch (
    branch_id TEXT PRIMARY KEY,
    branch_name TEXT NOT NULL,
    city TEXT NOT NULL,
    address TEXT NOT NULL,
    phone TEXT,
    opened_date TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('active', 'closed', 'renovation')),
    UNIQUE (branch_name, city)
);

CREATE TABLE member (
    member_id TEXT PRIMARY KEY,
    home_branch_id TEXT NOT NULL,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    phone TEXT,
    member_type TEXT NOT NULL CHECK (member_type IN ('student', 'faculty', 'staff', 'public')),
    department_or_program TEXT,
    join_date TEXT NOT NULL,
    expiry_date TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('active', 'suspended', 'expired')),
    max_active_loans INTEGER NOT NULL DEFAULT 5 CHECK (max_active_loans BETWEEN 1 AND 20),
    FOREIGN KEY (home_branch_id) REFERENCES library_branch (branch_id),
    CHECK (expiry_date > join_date)
);

CREATE TABLE librarian (
    librarian_id TEXT PRIMARY KEY,
    branch_id TEXT NOT NULL,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    role TEXT NOT NULL CHECK (role IN ('manager', 'analyst', 'circulation', 'admin')),
    hire_date TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('active', 'inactive')),
    FOREIGN KEY (branch_id) REFERENCES library_branch (branch_id)
);

CREATE TABLE publisher (
    publisher_id TEXT PRIMARY KEY,
    publisher_name TEXT NOT NULL UNIQUE,
    country TEXT,
    website TEXT
);

CREATE TABLE category (
    category_id TEXT PRIMARY KEY,
    parent_category_id TEXT,
    category_name TEXT NOT NULL,
    shelf_code TEXT NOT NULL UNIQUE,
    FOREIGN KEY (parent_category_id) REFERENCES category (category_id)
);

CREATE TABLE author (
    author_id TEXT PRIMARY KEY,
    full_name TEXT NOT NULL,
    nationality TEXT,
    birth_year INTEGER CHECK (birth_year IS NULL OR birth_year BETWEEN 1850 AND 2015)
);

CREATE TABLE book (
    book_id TEXT PRIMARY KEY,
    publisher_id TEXT NOT NULL,
    category_id TEXT NOT NULL,
    isbn TEXT NOT NULL UNIQUE,
    title TEXT NOT NULL,
    language TEXT NOT NULL,
    publication_year INTEGER NOT NULL CHECK (publication_year BETWEEN 1850 AND 2026),
    edition TEXT,
    page_count INTEGER NOT NULL CHECK (page_count > 0),
    target_audience TEXT NOT NULL CHECK (target_audience IN ('undergraduate', 'graduate', 'faculty', 'general')),
    FOREIGN KEY (publisher_id) REFERENCES publisher (publisher_id),
    FOREIGN KEY (category_id) REFERENCES category (category_id)
);

CREATE TABLE book_author (
    book_id TEXT NOT NULL,
    author_id TEXT NOT NULL,
    author_order INTEGER NOT NULL CHECK (author_order > 0),
    PRIMARY KEY (book_id, author_id),
    UNIQUE (book_id, author_order),
    FOREIGN KEY (book_id) REFERENCES book (book_id),
    FOREIGN KEY (author_id) REFERENCES author (author_id)
);

CREATE TABLE book_copy (
    copy_id TEXT PRIMARY KEY,
    book_id TEXT NOT NULL,
    branch_id TEXT NOT NULL,
    barcode TEXT NOT NULL UNIQUE,
    acquisition_date TEXT NOT NULL,
    purchase_price NUMERIC NOT NULL CHECK (purchase_price >= 0),
    shelf_location TEXT NOT NULL,
    condition_status TEXT NOT NULL CHECK (condition_status IN ('new', 'good', 'worn', 'damaged', 'lost')),
    availability_status TEXT NOT NULL CHECK (availability_status IN ('available', 'on_loan', 'reserved', 'maintenance', 'lost', 'retired')),
    is_reference_only INTEGER NOT NULL DEFAULT 0 CHECK (is_reference_only IN (0, 1)),
    FOREIGN KEY (book_id) REFERENCES book (book_id),
    FOREIGN KEY (branch_id) REFERENCES library_branch (branch_id)
);

CREATE TABLE loan (
    loan_id TEXT PRIMARY KEY,
    member_id TEXT NOT NULL,
    copy_id TEXT NOT NULL,
    checkout_librarian_id TEXT NOT NULL,
    checkin_librarian_id TEXT,
    checkout_date TEXT NOT NULL,
    due_date TEXT NOT NULL,
    return_date TEXT,
    renewal_count INTEGER NOT NULL DEFAULT 0 CHECK (renewal_count BETWEEN 0 AND 3),
    loan_status TEXT NOT NULL CHECK (loan_status IN ('active', 'returned', 'overdue', 'lost')),
    FOREIGN KEY (member_id) REFERENCES member (member_id),
    FOREIGN KEY (copy_id) REFERENCES book_copy (copy_id),
    FOREIGN KEY (checkout_librarian_id) REFERENCES librarian (librarian_id),
    FOREIGN KEY (checkin_librarian_id) REFERENCES librarian (librarian_id),
    CHECK (due_date > checkout_date),
    CHECK (return_date IS NULL OR return_date >= checkout_date),
    CHECK (
        (loan_status = 'returned' AND return_date IS NOT NULL)
        OR (loan_status IN ('active', 'overdue', 'lost') AND return_date IS NULL)
    )
);

CREATE TABLE reservation (
    reservation_id TEXT PRIMARY KEY,
    member_id TEXT NOT NULL,
    book_id TEXT NOT NULL,
    handled_by_librarian_id TEXT,
    fulfilled_loan_id TEXT UNIQUE,
    reservation_date TEXT NOT NULL,
    expiry_date TEXT NOT NULL,
    reservation_status TEXT NOT NULL CHECK (reservation_status IN ('waiting', 'ready_for_pickup', 'fulfilled', 'cancelled', 'expired')),
    queue_position INTEGER CHECK (queue_position IS NULL OR queue_position > 0),
    FOREIGN KEY (member_id) REFERENCES member (member_id),
    FOREIGN KEY (book_id) REFERENCES book (book_id),
    FOREIGN KEY (handled_by_librarian_id) REFERENCES librarian (librarian_id),
    FOREIGN KEY (fulfilled_loan_id) REFERENCES loan (loan_id),
    CHECK (expiry_date > reservation_date),
    CHECK (
        (reservation_status = 'waiting' AND queue_position IS NOT NULL)
        OR (reservation_status <> 'waiting')
    )
);

CREATE TABLE fine (
    fine_id TEXT PRIMARY KEY,
    member_id TEXT NOT NULL,
    loan_id TEXT NOT NULL,
    assessed_date TEXT NOT NULL,
    fine_type TEXT NOT NULL CHECK (fine_type IN ('late_return', 'lost_item', 'damage', 'processing')),
    amount NUMERIC NOT NULL CHECK (amount >= 0),
    paid_amount NUMERIC NOT NULL DEFAULT 0 CHECK (paid_amount >= 0),
    fine_status TEXT NOT NULL CHECK (fine_status IN ('unpaid', 'partially_paid', 'paid', 'waived')),
    payment_date TEXT,
    notes TEXT,
    FOREIGN KEY (member_id) REFERENCES member (member_id),
    FOREIGN KEY (loan_id) REFERENCES loan (loan_id),
    CHECK (paid_amount <= amount),
    CHECK (payment_date IS NULL OR payment_date >= assessed_date),
    CHECK (
        (fine_status IN ('paid', 'partially_paid') AND payment_date IS NOT NULL)
        OR (fine_status IN ('unpaid', 'waived'))
    )
);

