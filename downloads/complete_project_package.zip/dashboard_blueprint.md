# Looker Studio Dashboard Blueprint

Project: Central University Library Management System
Student: Mohadese Nejati
Course: Business Intelligence
University: Sharif University
Professor: Dr. Ghodosi

## Data Source Setup

Upload these files from `outputs/` to Google Sheets, then connect each Sheet to Looker Studio:

| File | Looker data source name | Main use |
|---|---|---|
| looker_loan_detail.csv | Loan Detail | Loan trend, overdue risk, branch performance, operator workload |
| looker_reservation_detail.csv | Reservation Detail | Reservation queue, request status, category demand |
| looker_fine_detail.csv | Fine Detail | Fine balance, payment status, financial exposure |
| looker_book_demand.csv | Book Demand | Purchase recommendations, availability, high-demand books |
| kpi_summary.csv | KPI Summary | Optional executive KPI lookup table |

Recommended report controls:

- Date range control: `checkout_date` for Loan Detail.
- Drop-down filter: `branch_name`.
- Drop-down filter: `category_name`.
- Drop-down filter: `member_type`.
- Drop-down filter: `loan_status`.
- Optional filter: `checkout_librarian`.

## Calculated Fields

Create these calculated fields in Looker Studio where useful:

| Field | Formula idea | Source |
|---|---|---|
| Loan Count | `COUNT_DISTINCT(loan_id)` | Loan Detail |
| Active Loan Count | count where `loan_status = active` | Loan Detail |
| Overdue Loan Count | count where `loan_status = overdue` | Loan Detail |
| Overdue Rate | `Overdue Loan Count / (Active Loan Count + Overdue Loan Count)` | Loan Detail |
| Outstanding Fine | `SUM(outstanding_amount)` | Fine Detail |
| Availability Rate | `SUM(available_copies) / SUM(total_copies)` | Book Demand |
| Purchase Need Score | existing field `purchase_need_score` | Book Demand |

## Page 1: Manager

Purpose: strategic decision-making for collection investment, risk, and branch performance.

Charts:

| # | Chart | Data source | Dimension | Metric | Unit | Management question |
|---|---|---|---|---|---|---|
| 1 | KPI card | Loan Detail | none | Loan Count | loans | How much is the library used? |
| 2 | KPI card | Loan Detail | none | Overdue Rate | percent | How serious is circulation risk? |
| 3 | KPI card | Book Demand | none | SUM(available_copies) | copies | How much stock is immediately usable? |
| 4 | KPI card | Fine Detail | none | Outstanding Fine | amount | How much fine balance is unpaid? |
| 5 | Time series | Loan Detail | checkout_date by month | Loan Count | loans/month | What is the borrowing trend? |
| 6 | Bar chart | Loan Detail | branch_name | Loan Count | loans | Which branch has the highest workload? |
| 7 | Ranking table | Book Demand | title, category_name | purchase_need_score, reservation_count, available_copies | score/count | Which books should be purchased first? |
| 8 | Donut chart | Reservation Detail | reservation_status | COUNT_DISTINCT(reservation_id) | reservations | Are requests fulfilled or stuck? |

Manager text insight box:

- Prioritize books with high purchase need score.
- Review staffing and copy allocation for the branch with highest loan volume.
- Track overdue categories weekly.
- Use reservations as early evidence of unmet demand.

## Page 2: Analyst / Operator

Purpose: daily operational control.

Charts:

| # | Chart | Data source | Dimension | Metric | Unit | Operational question |
|---|---|---|---|---|---|---|
| 1 | KPI card | Loan Detail | none | Active Loan Count | loans | How many loans are still open? |
| 2 | KPI card | Loan Detail | none | Overdue Loan Count | loans | How many need follow-up? |
| 3 | KPI card | Reservation Detail | none | waiting reservations | reservations | How large is the current queue? |
| 4 | Bar chart | Loan Detail | category_name | Overdue Loan Count | loans | Which category needs reminders? |
| 5 | Table | Loan Detail | loan_id, title, member_type, branch_name, due_date | loan_status | rows | Which loans should staff handle today? |
| 6 | Bar chart | Loan Detail | checkout_librarian | Loan Count | loans | How is operator workload distributed? |
| 7 | Table | Book Demand | title, category_name, available_copies, total_copies | purchase_need_score | rows | Which books have stock pressure? |

## Page 3: External User / Member

Purpose: member-facing visibility and self-service support.

Charts:

| # | Chart | Data source | Dimension | Metric | Unit | User question |
|---|---|---|---|---|---|---|
| 1 | KPI card | Book Demand | none | Availability Rate | percent | Are books generally available? |
| 2 | Search table | Book Demand | title, category_name | available_copies, total_copies | copies | Is a desired book available? |
| 3 | Table | Reservation Detail | title, reservation_status | COUNT_DISTINCT(reservation_id) | reservations | What is the reservation situation? |
| 4 | Table | Fine Detail | fine_type, fine_status | SUM(outstanding_amount) | amount | Are there unpaid fines? |
| 5 | Bar chart | Loan Detail | member_type | Loan Count | loans | Which user group uses the library most? |

## Visual Style

- Use a modern professional theme: white background, dark navy headers, restrained blue/green/amber accents.
- Keep pages dense and operational, not like a marketing page.
- Use consistent number formatting: counts as whole numbers, rates as percentages, fines with two decimals.
- Every chart must have a title, unit of measurement, and one-sentence interpretation.
- Share the final report with view access for Dr. Ghodosi.
