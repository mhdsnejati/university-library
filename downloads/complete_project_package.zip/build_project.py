from __future__ import annotations

import csv
import html
import json
import random
import sqlite3
from collections import Counter, defaultdict
from datetime import date, timedelta
from pathlib import Path


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
OUTPUT_DIR = ROOT / "outputs"
REPORT_DIR = ROOT / "report"
DASHBOARD_DIR = ROOT / "dashboard"
DB_DIR = ROOT / "db"
TODAY = date(2026, 7, 8)
RNG = random.Random(1107)

PROJECT_TITLE = "Central University Library Management System"
COURSE_NAME = "Business Intelligence"
STUDENT_NAME = "Mohadese Nejati"
UNIVERSITY_NAME = "Sharif University"
PROFESSOR_NAME = "Dr. Ghodosi"
DELIVERY_DATE = "20 Mordad"
DATA_POSITIONING = (
    "near-real assumed operational data: a privacy-safe course dataset designed to behave like a real "
    "university library export while preserving complete ERD consistency"
)


TABLE_FIELDS = {
    "library_branch": [
        "branch_id",
        "branch_name",
        "city",
        "address",
        "phone",
        "opened_date",
        "status",
    ],
    "member": [
        "member_id",
        "home_branch_id",
        "full_name",
        "email",
        "phone",
        "member_type",
        "department_or_program",
        "join_date",
        "expiry_date",
        "status",
        "max_active_loans",
    ],
    "librarian": [
        "librarian_id",
        "branch_id",
        "full_name",
        "email",
        "role",
        "hire_date",
        "status",
    ],
    "publisher": ["publisher_id", "publisher_name", "country", "website"],
    "category": ["category_id", "parent_category_id", "category_name", "shelf_code"],
    "author": ["author_id", "full_name", "nationality", "birth_year"],
    "book": [
        "book_id",
        "publisher_id",
        "category_id",
        "isbn",
        "title",
        "language",
        "publication_year",
        "edition",
        "page_count",
        "target_audience",
    ],
    "book_author": ["book_id", "author_id", "author_order"],
    "book_copy": [
        "copy_id",
        "book_id",
        "branch_id",
        "barcode",
        "acquisition_date",
        "purchase_price",
        "shelf_location",
        "condition_status",
        "availability_status",
        "is_reference_only",
    ],
    "loan": [
        "loan_id",
        "member_id",
        "copy_id",
        "checkout_librarian_id",
        "checkin_librarian_id",
        "checkout_date",
        "due_date",
        "return_date",
        "renewal_count",
        "loan_status",
    ],
    "reservation": [
        "reservation_id",
        "member_id",
        "book_id",
        "handled_by_librarian_id",
        "fulfilled_loan_id",
        "reservation_date",
        "expiry_date",
        "reservation_status",
        "queue_position",
    ],
    "fine": [
        "fine_id",
        "member_id",
        "loan_id",
        "assessed_date",
        "fine_type",
        "amount",
        "paid_amount",
        "fine_status",
        "payment_date",
        "notes",
    ],
}


def iso(value: date | None) -> str | None:
    return value.isoformat() if value else None


def parse_date(value: str) -> date:
    return date.fromisoformat(value)


def random_date(start: date, end: date) -> date:
    if end < start:
        return start
    return start + timedelta(days=RNG.randint(0, (end - start).days))


def choose_weighted(items: list[dict], weight_key: str) -> dict:
    total = sum(float(item[weight_key]) for item in items)
    pick = RNG.random() * total
    running = 0.0
    for item in items:
        running += float(item[weight_key])
        if running >= pick:
            return item
    return items[-1]


def clean_row(row: dict, fields: list[str]) -> dict:
    return {field: row.get(field) for field in fields}


def write_csv(path: Path, fields: list[str], rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: "" if row.get(field) is None else row.get(field) for field in fields})


def read_query(conn: sqlite3.Connection, query: str) -> list[dict]:
    conn.row_factory = sqlite3.Row
    return [dict(row) for row in conn.execute(query)]


def money(value: float) -> str:
    return f"{value:,.2f}"


def generate_reference_data() -> dict[str, list[dict]]:
    branches = [
        {
            "branch_id": "BR001",
            "branch_name": "Central Library",
            "city": "Tehran",
            "address": "Main Campus, Azadi Avenue",
            "phone": "+98-21-6600-1001",
            "opened_date": "1974-09-21",
            "status": "active",
        },
        {
            "branch_id": "BR002",
            "branch_name": "Engineering Library",
            "city": "Tehran",
            "address": "Engineering Faculty Building",
            "phone": "+98-21-6600-1002",
            "opened_date": "1988-02-14",
            "status": "active",
        },
        {
            "branch_id": "BR003",
            "branch_name": "Medical Sciences Library",
            "city": "Tehran",
            "address": "Health Sciences Campus",
            "phone": "+98-21-6600-1003",
            "opened_date": "1996-11-04",
            "status": "active",
        },
        {
            "branch_id": "BR004",
            "branch_name": "Graduate Research Library",
            "city": "Tehran",
            "address": "Graduate Studies Complex",
            "phone": "+98-21-6600-1004",
            "opened_date": "2006-05-18",
            "status": "active",
        },
    ]

    categories = [
        ("CAT001", None, "Science", "SCI"),
        ("CAT002", None, "Engineering", "ENG"),
        ("CAT003", None, "Humanities", "HUM"),
        ("CAT004", None, "Social Sciences", "SOC"),
        ("CAT005", "CAT002", "Computer Science", "CS"),
        ("CAT006", "CAT002", "Electrical Engineering", "EE"),
        ("CAT007", "CAT002", "Mechanical Engineering", "ME"),
        ("CAT008", "CAT002", "Civil Engineering", "CE"),
        ("CAT009", "CAT001", "Mathematics", "MATH"),
        ("CAT010", "CAT001", "Physics", "PHYS"),
        ("CAT011", "CAT001", "Chemistry", "CHEM"),
        ("CAT012", "CAT004", "Economics", "ECON"),
        ("CAT013", "CAT004", "Management", "MGMT"),
        ("CAT014", "CAT004", "Psychology", "PSY"),
        ("CAT015", "CAT003", "Literature", "LIT"),
        ("CAT016", "CAT003", "History", "HIST"),
        ("CAT017", "CAT003", "Philosophy", "PHIL"),
        ("CAT018", "CAT001", "Biology", "BIO"),
    ]
    categories = [
        {
            "category_id": row[0],
            "parent_category_id": row[1],
            "category_name": row[2],
            "shelf_code": row[3],
        }
        for row in categories
    ]

    publisher_names = [
        "Academic Press",
        "Cambridge University Press",
        "Oxford University Press",
        "Springer",
        "Wiley",
        "Pearson",
        "McGraw Hill",
        "MIT Press",
        "Routledge",
        "Elsevier",
        "CRC Press",
        "Sage",
        "Taylor and Francis",
        "Princeton University Press",
        "Harvard University Press",
        "Tehran Academic Publishing",
        "Noor Science Press",
        "Daneshgahi Publications",
        "Industrial Engineering Press",
        "Global Research Books",
        "Knowledge House",
        "Data and Society Press",
        "CivilWorks Press",
        "MedLearn Publishing",
        "Arman Ketab",
        "Pishro Publications",
        "StatLab Books",
        "Learning Systems Press",
        "Policy Insight Press",
        "Modern Humanities Press",
        "Applied Science House",
        "University Textbook Center",
    ]
    countries = ["USA", "UK", "Germany", "Netherlands", "Iran", "Canada", "France"]
    publishers = []
    for idx, name in enumerate(publisher_names, start=1):
        publishers.append(
            {
                "publisher_id": f"PUB{idx:03d}",
                "publisher_name": name,
                "country": RNG.choice(countries),
                "website": f"https://example.org/{name.lower().replace(' ', '-')}",
            }
        )

    first_names = [
        "Ali",
        "Sara",
        "Reza",
        "Neda",
        "Omid",
        "Mina",
        "Kian",
        "Maryam",
        "Arman",
        "Leila",
        "Navid",
        "Yasmin",
        "Amir",
        "Roya",
        "Sina",
        "Tara",
        "David",
        "Emma",
        "Liam",
        "Sophia",
        "Noah",
        "Olivia",
        "Lucas",
        "Maya",
        "Hana",
        "Karim",
    ]
    last_names = [
        "Ahmadi",
        "Karimi",
        "Hosseini",
        "Rahimi",
        "Moradi",
        "Ebrahimi",
        "Nouri",
        "Farhadi",
        "Abbasi",
        "Mousavi",
        "Wilson",
        "Brown",
        "Taylor",
        "Johnson",
        "Clark",
        "Martin",
        "Garcia",
        "Lee",
        "Chen",
        "Patel",
        "Khan",
        "Smith",
    ]
    nationalities = ["Iranian", "American", "British", "Canadian", "German", "Indian", "Chinese", "French"]
    authors = []
    for idx in range(1, 181):
        authors.append(
            {
                "author_id": f"A{idx:04d}",
                "full_name": f"{RNG.choice(first_names)} {RNG.choice(last_names)}",
                "nationality": RNG.choice(nationalities),
                "birth_year": RNG.randint(1935, 1994),
            }
        )

    librarians = []
    roles = ["manager"] * 3 + ["analyst"] * 4 + ["circulation"] * 9 + ["admin"] * 2
    for idx, role in enumerate(roles, start=1):
        branch = branches[(idx - 1) % len(branches)]
        full_name = f"{RNG.choice(first_names)} {RNG.choice(last_names)}"
        librarians.append(
            {
                "librarian_id": f"L{idx:03d}",
                "branch_id": branch["branch_id"],
                "full_name": full_name,
                "email": f"librarian{idx:03d}@library.example.edu",
                "role": role,
                "hire_date": iso(random_date(date(2012, 1, 1), date(2025, 9, 1))),
                "status": "active" if RNG.random() < 0.94 else "inactive",
            }
        )

    return {
        "library_branch": branches,
        "category": categories,
        "publisher": publishers,
        "author": authors,
        "librarian": librarians,
    }


def generate_members(branches: list[dict]) -> list[dict]:
    first_names = [
        "Ali",
        "Sara",
        "Reza",
        "Neda",
        "Omid",
        "Mina",
        "Kian",
        "Maryam",
        "Arman",
        "Leila",
        "Navid",
        "Yasmin",
        "Amir",
        "Roya",
        "Sina",
        "Tara",
        "Elham",
        "Pouya",
        "Shirin",
        "Mahsa",
    ]
    last_names = [
        "Ahmadi",
        "Karimi",
        "Hosseini",
        "Rahimi",
        "Moradi",
        "Ebrahimi",
        "Nouri",
        "Farhadi",
        "Abbasi",
        "Mousavi",
        "Jafari",
        "Sadeghi",
        "Sharifi",
        "Ghasemi",
    ]
    departments = [
        "Computer Engineering",
        "Industrial Engineering",
        "Electrical Engineering",
        "Mechanical Engineering",
        "Civil Engineering",
        "Mathematics",
        "Physics",
        "Chemistry",
        "Economics",
        "Management",
        "Literature",
        "History",
        "Psychology",
        "Public Membership",
    ]
    type_limits = {"student": 5, "faculty": 10, "staff": 6, "public": 3}
    members = []
    for idx in range(1, 521):
        member_type = RNG.choices(
            ["student", "faculty", "staff", "public"],
            weights=[0.68, 0.13, 0.11, 0.08],
            k=1,
        )[0]
        join_date = random_date(date(2021, 1, 1), date(2026, 5, 15))
        if RNG.random() < 0.09:
            expiry_date = random_date(join_date + timedelta(days=180), TODAY - timedelta(days=1))
            status = "expired"
        else:
            expiry_date = random_date(max(join_date + timedelta(days=365), TODAY), date(2028, 12, 31))
            status = "suspended" if RNG.random() < 0.055 else "active"
        full_name = f"{RNG.choice(first_names)} {RNG.choice(last_names)}"
        members.append(
            {
                "member_id": f"M{idx:06d}",
                "home_branch_id": RNG.choice(branches)["branch_id"],
                "full_name": full_name,
                "email": f"member{idx:06d}@student.example.edu",
                "phone": f"+98-912-{RNG.randint(1000000, 9999999)}",
                "member_type": member_type,
                "department_or_program": "" if member_type == "public" else RNG.choice(departments[:-1]),
                "join_date": iso(join_date),
                "expiry_date": iso(expiry_date),
                "status": status,
                "max_active_loans": type_limits[member_type],
            }
        )
    return members


def title_for_category(category_name: str, idx: int) -> str:
    topics = {
        "Computer Science": ["Data Mining", "Database Systems", "Machine Learning", "Cloud Computing", "Algorithms"],
        "Electrical Engineering": ["Signal Processing", "Control Systems", "Power Networks", "Digital Circuits"],
        "Mechanical Engineering": ["Thermodynamics", "Fluid Mechanics", "Robotics", "Manufacturing Systems"],
        "Civil Engineering": ["Structural Analysis", "Urban Infrastructure", "Construction Planning", "Soil Mechanics"],
        "Mathematics": ["Linear Algebra", "Probability Theory", "Numerical Methods", "Discrete Mathematics"],
        "Physics": ["Quantum Mechanics", "Classical Mechanics", "Optics", "Statistical Physics"],
        "Chemistry": ["Organic Chemistry", "Analytical Chemistry", "Materials Chemistry", "Laboratory Methods"],
        "Economics": ["Microeconomics", "Development Economics", "Econometrics", "Public Policy"],
        "Management": ["Operations Management", "Business Analytics", "Strategic Management", "Project Management"],
        "Psychology": ["Cognitive Psychology", "Learning Theory", "Research Methods", "Behavioral Analysis"],
        "Literature": ["World Literature", "Persian Poetry", "Modern Fiction", "Literary Criticism"],
        "History": ["Modern Iran", "World History", "Historical Methods", "Urban History"],
        "Philosophy": ["Ethics", "Logic", "Philosophy of Science", "Political Philosophy"],
        "Biology": ["Molecular Biology", "Genetics", "Ecology", "Cell Biology"],
    }
    suffixes = [
        "Principles and Applications",
        "An Applied Introduction",
        "Methods for Researchers",
        "Case Studies and Practice",
        "A Modern Approach",
        "Concepts, Models, and Tools",
    ]
    base = RNG.choice(topics.get(category_name, [category_name]))
    return f"{base}: {RNG.choice(suffixes)} {idx}"


def generate_books(reference: dict[str, list[dict]]) -> tuple[list[dict], list[dict]]:
    publishers = reference["publisher"]
    categories = [item for item in reference["category"] if item["parent_category_id"]]
    authors = reference["author"]
    category_weights = {
        "Computer Science": 1.8,
        "Management": 1.5,
        "Mathematics": 1.4,
        "Electrical Engineering": 1.3,
        "Economics": 1.25,
        "Mechanical Engineering": 1.15,
    }
    weighted_categories = []
    for category in categories:
        item = dict(category)
        item["weight"] = category_weights.get(category["category_name"], 1.0)
        weighted_categories.append(item)

    books = []
    book_authors = []
    seen_isbns = set()
    for idx in range(1, 321):
        category = choose_weighted(weighted_categories, "weight")
        year = RNG.randint(1990, 2026)
        isbn = f"978{RNG.randint(1000000000, 9999999999)}"
        while isbn in seen_isbns:
            isbn = f"978{RNG.randint(1000000000, 9999999999)}"
        seen_isbns.add(isbn)
        audience = RNG.choices(
            ["undergraduate", "graduate", "faculty", "general"],
            weights=[0.48, 0.32, 0.12, 0.08],
            k=1,
        )[0]
        books.append(
            {
                "book_id": f"B{idx:06d}",
                "publisher_id": RNG.choice(publishers)["publisher_id"],
                "category_id": category["category_id"],
                "isbn": isbn,
                "title": title_for_category(category["category_name"], idx),
                "language": RNG.choices(["English", "Persian", "Arabic"], weights=[0.66, 0.31, 0.03], k=1)[0],
                "publication_year": year,
                "edition": f"{RNG.randint(1, 6)}th edition",
                "page_count": RNG.randint(120, 980),
                "target_audience": audience,
            }
        )
        author_count = RNG.choices([1, 2, 3], weights=[0.68, 0.25, 0.07], k=1)[0]
        for order, author in enumerate(RNG.sample(authors, author_count), start=1):
            book_authors.append(
                {
                    "book_id": f"B{idx:06d}",
                    "author_id": author["author_id"],
                    "author_order": order,
                }
            )
    return books, book_authors


def generate_copies(books: list[dict], categories: list[dict], branches: list[dict]) -> list[dict]:
    category_by_id = {row["category_id"]: row for row in categories}
    high_demand = {"Computer Science", "Management", "Mathematics", "Electrical Engineering", "Economics"}
    copies = []
    copy_idx = 1
    for book in books:
        category = category_by_id[book["category_id"]]["category_name"]
        base = 2 if category not in high_demand else 3
        copy_count = max(1, int(RNG.gauss(base + (2026 - int(book["publication_year"])) / 22, 1.1)))
        if RNG.random() < 0.18:
            copy_count += 2
        for _ in range(copy_count):
            branch = RNG.choices(branches, weights=[0.35, 0.29, 0.16, 0.20], k=1)[0]
            age = max(0, TODAY.year - int(book["publication_year"]))
            condition = RNG.choices(
                ["new", "good", "worn", "damaged"],
                weights=[max(1, 12 - age), 62, 18 + age / 3, 4],
                k=1,
            )[0]
            acquisition_start = date(max(int(book["publication_year"]), 2005), 1, 1)
            acquisition_date = random_date(acquisition_start, TODAY - timedelta(days=30))
            copies.append(
                {
                    "copy_id": f"C{copy_idx:06d}",
                    "book_id": book["book_id"],
                    "branch_id": branch["branch_id"],
                    "barcode": f"UL-{copy_idx:08d}",
                    "acquisition_date": iso(acquisition_date),
                    "purchase_price": round(RNG.uniform(8.0, 95.0), 2),
                    "shelf_location": f"{category_by_id[book['category_id']]['shelf_code']}-{RNG.choice(['A', 'B', 'C', 'D'])}{RNG.randint(1, 9)}-{RNG.randint(1, 42):02d}",
                    "condition_status": condition,
                    "availability_status": "available",
                    "is_reference_only": 1 if RNG.random() < 0.08 else 0,
                }
            )
            copy_idx += 1
    return copies


def generate_loans(
    members: list[dict],
    copies: list[dict],
    librarians: list[dict],
) -> tuple[list[dict], dict[str, dict], dict[str, int]]:
    active_librarians = [row for row in librarians if row["status"] == "active"]
    copy_by_id = {row["copy_id"]: row for row in copies}
    eligible_copies = [
        row
        for row in copies
        if not row["is_reference_only"] and row["condition_status"] not in {"lost", "damaged"}
    ]
    next_available = {row["copy_id"]: date(2024, 1, 1) for row in eligible_copies}
    member_open_counts = defaultdict(int)
    open_loan_by_copy: dict[str, dict] = {}
    loan_rows = []
    checkout_dates = sorted(random_date(date(2024, 9, 1), TODAY - timedelta(days=1)) for _ in range(2200))

    for idx, checkout_date in enumerate(checkout_dates, start=1):
        can_be_open = checkout_date >= TODAY - timedelta(days=55)
        loan_days = RNG.choices([14, 21, 28], weights=[0.55, 0.35, 0.10], k=1)[0]
        due_date = checkout_date + timedelta(days=loan_days + RNG.choice([0, 0, 0, 7]))
        status_roll = RNG.random()
        if can_be_open and due_date >= TODAY and status_roll < 0.30:
            status = "active"
        elif can_be_open and due_date < TODAY and status_roll < 0.14:
            status = "overdue"
        elif due_date < TODAY and status_roll < 0.018:
            status = "lost"
        else:
            status = "returned"

        if status == "returned" and checkout_date > TODAY - timedelta(days=3):
            status = "active"
            due_date = max(due_date, TODAY + timedelta(days=7))

        if status in {"active", "overdue", "lost"}:
            member_candidates = [
                row
                for row in members
                if row["status"] == "active"
                and parse_date(row["join_date"]) <= checkout_date
                and parse_date(row["expiry_date"]) >= checkout_date
                and member_open_counts[row["member_id"]] < int(row["max_active_loans"])
            ]
        else:
            member_candidates = [
                row
                for row in members
                if parse_date(row["join_date"]) <= checkout_date
                and parse_date(row["expiry_date"]) >= checkout_date
            ]
        member = RNG.choice(member_candidates)

        copy = None
        for _ in range(80):
            candidate = RNG.choice(eligible_copies)
            if next_available[candidate["copy_id"]] <= checkout_date:
                copy = candidate
                break
        if copy is None:
            available_candidates = [
                candidate
                for candidate in eligible_copies
                if next_available[candidate["copy_id"]] <= checkout_date
            ]
            copy = RNG.choice(available_candidates)

        checkout_librarian = RNG.choice(active_librarians)
        renewal_count = RNG.choices([0, 1, 2, 3], weights=[0.72, 0.18, 0.08, 0.02], k=1)[0]
        return_date = None
        checkin_librarian = None
        if status == "returned":
            max_return_days = min((TODAY - checkout_date).days, loan_days + 35)
            if RNG.random() < 0.18:
                days_to_return = min(max_return_days, loan_days + RNG.randint(1, 24))
            else:
                days_to_return = RNG.randint(2, max(2, min(loan_days, max_return_days)))
            return_date = checkout_date + timedelta(days=days_to_return)
            checkin_librarian = RNG.choice(active_librarians)["librarian_id"]
            next_available[copy["copy_id"]] = return_date + timedelta(days=1)
        else:
            next_available[copy["copy_id"]] = TODAY + timedelta(days=3650)
            member_open_counts[member["member_id"]] += 1

        row = {
            "loan_id": f"LN{idx:06d}",
            "member_id": member["member_id"],
            "copy_id": copy["copy_id"],
            "checkout_librarian_id": checkout_librarian["librarian_id"],
            "checkin_librarian_id": checkin_librarian,
            "checkout_date": iso(checkout_date),
            "due_date": iso(due_date),
            "return_date": iso(return_date),
            "renewal_count": renewal_count,
            "loan_status": status,
        }
        loan_rows.append(row)
        if status in {"active", "overdue", "lost"}:
            open_loan_by_copy[copy["copy_id"]] = row

    for copy_id, loan in open_loan_by_copy.items():
        copy = copy_by_id[copy_id]
        if loan["loan_status"] == "lost":
            copy["availability_status"] = "lost"
            copy["condition_status"] = "lost"
        else:
            copy["availability_status"] = "on_loan"

    for copy in copies:
        if copy["availability_status"] == "available":
            if copy["condition_status"] == "damaged" and RNG.random() < 0.75:
                copy["availability_status"] = "maintenance"
            elif copy["condition_status"] == "worn" and RNG.random() < 0.05:
                copy["availability_status"] = "maintenance"
            elif RNG.random() < 0.018:
                copy["availability_status"] = "retired"

    return loan_rows, open_loan_by_copy, member_open_counts


def generate_reservations(
    members: list[dict],
    books: list[dict],
    copies: list[dict],
    loans: list[dict],
    librarians: list[dict],
) -> list[dict]:
    book_by_copy = {copy["copy_id"]: copy["book_id"] for copy in copies}
    loan_candidates = [
        loan
        for loan in loans
        if parse_date(loan["checkout_date"]) > date(2024, 10, 1)
    ]
    reservation_rows = []
    used_fulfilled_loans = set()
    active_members = [member for member in members if member["status"] == "active"]
    active_librarians = [row for row in librarians if row["status"] == "active"]
    popular_books = Counter(book_by_copy[loan["copy_id"]] for loan in loans)
    weighted_books = []
    for book in books:
        row = dict(book)
        row["weight"] = 1 + popular_books[book["book_id"]] / 6
        weighted_books.append(row)

    for idx, loan in enumerate(RNG.sample(loan_candidates, 260), start=1):
        checkout = parse_date(loan["checkout_date"])
        reservation_date = checkout - timedelta(days=RNG.randint(1, 18))
        member = next(row for row in members if row["member_id"] == loan["member_id"])
        join = parse_date(member["join_date"])
        if reservation_date < join:
            reservation_date = join
        reservation_rows.append(
            {
                "reservation_id": f"R{idx:06d}",
                "member_id": loan["member_id"],
                "book_id": book_by_copy[loan["copy_id"]],
                "handled_by_librarian_id": RNG.choice(active_librarians)["librarian_id"] if RNG.random() < 0.35 else None,
                "fulfilled_loan_id": loan["loan_id"],
                "reservation_date": iso(reservation_date),
                "expiry_date": iso(checkout + timedelta(days=2)),
                "reservation_status": "fulfilled",
                "queue_position": None,
            }
        )
        used_fulfilled_loans.add(loan["loan_id"])

    for idx in range(len(reservation_rows) + 1, 651):
        status = RNG.choices(
            ["waiting", "ready_for_pickup", "cancelled", "expired"],
            weights=[0.28, 0.10, 0.33, 0.29],
            k=1,
        )[0]
        if status in {"waiting", "ready_for_pickup"}:
            reservation_date = random_date(TODAY - timedelta(days=22), TODAY - timedelta(days=1))
            expiry_date = TODAY + timedelta(days=RNG.randint(1, 8))
        elif status == "expired":
            reservation_date = random_date(date(2024, 10, 1), TODAY - timedelta(days=20))
            expiry_date = reservation_date + timedelta(days=RNG.randint(3, 12))
            if expiry_date >= TODAY:
                expiry_date = TODAY - timedelta(days=1)
        else:
            reservation_date = random_date(date(2024, 10, 1), TODAY - timedelta(days=2))
            expiry_date = reservation_date + timedelta(days=RNG.randint(3, 12))

        reservation_rows.append(
            {
                "reservation_id": f"R{idx:06d}",
                "member_id": RNG.choice(active_members)["member_id"],
                "book_id": choose_weighted(weighted_books, "weight")["book_id"],
                "handled_by_librarian_id": RNG.choice(active_librarians)["librarian_id"] if RNG.random() < 0.42 else None,
                "fulfilled_loan_id": None,
                "reservation_date": iso(reservation_date),
                "expiry_date": iso(expiry_date),
                "reservation_status": status,
                "queue_position": RNG.randint(1, 18) if status == "waiting" else None,
            }
        )
    return reservation_rows


def generate_fines(
    members: list[dict],
    copies: list[dict],
    loans: list[dict],
) -> list[dict]:
    copy_by_id = {row["copy_id"]: row for row in copies}
    fine_rows = []
    fine_idx = 1

    def append_fine(loan: dict, fine_type: str, amount: float, assessed_date: date, notes: str) -> None:
        nonlocal fine_idx
        status = RNG.choices(
            ["paid", "partially_paid", "unpaid", "waived"],
            weights=[0.52, 0.16, 0.25, 0.07],
            k=1,
        )[0]
        if status == "paid":
            paid_amount = round(amount, 2)
            payment_date = random_date(assessed_date, min(TODAY, assessed_date + timedelta(days=45)))
        elif status == "partially_paid":
            paid_amount = round(amount * RNG.uniform(0.2, 0.78), 2)
            payment_date = random_date(assessed_date, min(TODAY, assessed_date + timedelta(days=45)))
        else:
            paid_amount = 0.0
            payment_date = None
        fine_rows.append(
            {
                "fine_id": f"F{fine_idx:06d}",
                "member_id": loan["member_id"],
                "loan_id": loan["loan_id"],
                "assessed_date": iso(assessed_date),
                "fine_type": fine_type,
                "amount": round(amount, 2),
                "paid_amount": paid_amount,
                "fine_status": status,
                "payment_date": iso(payment_date),
                "notes": notes,
            }
        )
        fine_idx += 1

    for loan in loans:
        due = parse_date(loan["due_date"])
        if loan["loan_status"] == "returned":
            returned = parse_date(loan["return_date"])
            late_days = (returned - due).days
            if late_days > 0:
                append_fine(
                    loan,
                    "late_return",
                    min(60.0, 0.75 * late_days),
                    returned,
                    f"Late return by {late_days} day(s)",
                )
            elif RNG.random() < 0.018:
                append_fine(
                    loan,
                    "damage",
                    RNG.uniform(8.0, 35.0),
                    returned,
                    "Minor damage found during check-in",
                )
        elif loan["loan_status"] == "lost":
            copy = copy_by_id[loan["copy_id"]]
            append_fine(
                loan,
                "lost_item",
                float(copy["purchase_price"]) + 20.0,
                min(TODAY, due + timedelta(days=35)),
                "Lost item replacement and processing charge",
            )

    returned_loans = [loan for loan in loans if loan["loan_status"] == "returned"]
    while len(fine_rows) < 180:
        loan = RNG.choice(returned_loans)
        assessed = parse_date(loan["return_date"])
        append_fine(loan, "processing", RNG.uniform(2.0, 9.0), assessed, "Administrative processing charge")
    return fine_rows


def create_database(rows_by_table: dict[str, list[dict]]) -> sqlite3.Connection:
    DB_DIR.mkdir(parents=True, exist_ok=True)
    db_path = DB_DIR / "university_library.db"
    if db_path.exists():
        db_path.unlink()
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.executescript((ROOT / "schema.sql").read_text(encoding="utf-8"))
    for table, fields in TABLE_FIELDS.items():
        placeholders = ", ".join("?" for _ in fields)
        sql = f"INSERT INTO {table} ({', '.join(fields)}) VALUES ({placeholders})"
        values = [[row.get(field) for field in fields] for row in rows_by_table[table]]
        conn.executemany(sql, values)
    conn.commit()
    return conn


def export_csvs(rows_by_table: dict[str, list[dict]]) -> None:
    for table, fields in TABLE_FIELDS.items():
        write_csv(DATA_DIR / f"{table}.csv", fields, rows_by_table[table])


def compute_metrics(conn: sqlite3.Connection) -> dict:
    metrics = {}
    one = lambda query: conn.execute(query).fetchone()[0]
    metrics["total_loans"] = int(one("SELECT COUNT(*) FROM loan"))
    metrics["active_loans"] = int(one("SELECT COUNT(*) FROM loan WHERE loan_status = 'active'"))
    metrics["overdue_loans"] = int(one("SELECT COUNT(*) FROM loan WHERE loan_status = 'overdue'"))
    metrics["lost_loans"] = int(one("SELECT COUNT(*) FROM loan WHERE loan_status = 'lost'"))
    metrics["returned_loans"] = int(one("SELECT COUNT(*) FROM loan WHERE loan_status = 'returned'"))
    metrics["available_copies"] = int(one("SELECT COUNT(*) FROM book_copy WHERE availability_status = 'available'"))
    metrics["total_copies"] = int(one("SELECT COUNT(*) FROM book_copy"))
    metrics["waiting_reservations"] = int(one("SELECT COUNT(*) FROM reservation WHERE reservation_status = 'waiting'"))
    metrics["total_reservations"] = int(one("SELECT COUNT(*) FROM reservation"))
    metrics["fine_balance"] = float(one("SELECT COALESCE(SUM(amount - paid_amount), 0) FROM fine"))
    metrics["paid_fines"] = float(one("SELECT COALESCE(SUM(paid_amount), 0) FROM fine"))
    open_total = metrics["active_loans"] + metrics["overdue_loans"]
    metrics["overdue_rate"] = round(metrics["overdue_loans"] / open_total * 100, 2) if open_total else 0
    metrics["availability_rate"] = round(metrics["available_copies"] / metrics["total_copies"] * 100, 2)

    metrics["top_borrowed_books"] = read_query(
        conn,
        """
        SELECT b.title, c.category_name, COUNT(*) AS loans
        FROM loan l
        JOIN book_copy bc ON bc.copy_id = l.copy_id
        JOIN book b ON b.book_id = bc.book_id
        JOIN category c ON c.category_id = b.category_id
        GROUP BY b.book_id, b.title, c.category_name
        ORDER BY loans DESC, b.title
        LIMIT 10
        """,
    )
    metrics["purchase_needs"] = read_query(
        conn,
        """
        WITH loan_counts AS (
            SELECT bc.book_id, COUNT(*) AS loan_count
            FROM loan l
            JOIN book_copy bc ON bc.copy_id = l.copy_id
            GROUP BY bc.book_id
        ),
        reservation_counts AS (
            SELECT book_id, COUNT(*) AS reservation_count
            FROM reservation
            GROUP BY book_id
        ),
        available_counts AS (
            SELECT book_id, SUM(CASE WHEN availability_status = 'available' THEN 1 ELSE 0 END) AS available_copies,
                   COUNT(*) AS total_copies
            FROM book_copy
            GROUP BY book_id
        )
        SELECT b.book_id, b.title, c.category_name,
               COALESCE(lc.loan_count, 0) AS loan_count,
               COALESCE(rc.reservation_count, 0) AS reservation_count,
               COALESCE(ac.available_copies, 0) AS available_copies,
               COALESCE(ac.total_copies, 0) AS total_copies,
               ROUND(COALESCE(rc.reservation_count, 0) * 2.2 + COALESCE(lc.loan_count, 0) * 0.55
                     - COALESCE(ac.available_copies, 0) * 1.5, 2) AS purchase_need_score
        FROM book b
        JOIN category c ON c.category_id = b.category_id
        LEFT JOIN loan_counts lc ON lc.book_id = b.book_id
        LEFT JOIN reservation_counts rc ON rc.book_id = b.book_id
        LEFT JOIN available_counts ac ON ac.book_id = b.book_id
        ORDER BY purchase_need_score DESC
        LIMIT 12
        """,
    )
    metrics["loans_by_month"] = read_query(
        conn,
        """
        SELECT substr(checkout_date, 1, 7) AS month, COUNT(*) AS loans
        FROM loan
        GROUP BY substr(checkout_date, 1, 7)
        ORDER BY month
        """,
    )
    metrics["loans_by_branch"] = read_query(
        conn,
        """
        SELECT lb.branch_name, COUNT(*) AS loans
        FROM loan l
        JOIN book_copy bc ON bc.copy_id = l.copy_id
        JOIN library_branch lb ON lb.branch_id = bc.branch_id
        GROUP BY lb.branch_name
        ORDER BY loans DESC
        """,
    )
    metrics["overdue_by_category"] = read_query(
        conn,
        """
        SELECT c.category_name, COUNT(*) AS overdue_loans
        FROM loan l
        JOIN book_copy bc ON bc.copy_id = l.copy_id
        JOIN book b ON b.book_id = bc.book_id
        JOIN category c ON c.category_id = b.category_id
        WHERE l.loan_status = 'overdue'
        GROUP BY c.category_name
        ORDER BY overdue_loans DESC
        LIMIT 10
        """,
    )
    metrics["reservation_status"] = read_query(
        conn,
        """
        SELECT reservation_status, COUNT(*) AS reservations
        FROM reservation
        GROUP BY reservation_status
        ORDER BY reservations DESC
        """,
    )
    metrics["operator_performance"] = read_query(
        conn,
        """
        SELECT lib.full_name, lib.role, COUNT(*) AS processed_loans
        FROM loan l
        JOIN librarian lib ON lib.librarian_id = l.checkout_librarian_id
        GROUP BY lib.librarian_id, lib.full_name, lib.role
        ORDER BY processed_loans DESC
        LIMIT 10
        """,
    )
    metrics["member_type_summary"] = read_query(
        conn,
        """
        SELECT m.member_type, COUNT(DISTINCT m.member_id) AS members, COUNT(l.loan_id) AS loans
        FROM member m
        LEFT JOIN loan l ON l.member_id = m.member_id
        GROUP BY m.member_type
        ORDER BY loans DESC
        """,
    )
    return metrics


def export_looker_views(conn: sqlite3.Connection, metrics: dict) -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    views = {
        "looker_loan_detail.csv": """
            SELECT l.loan_id, l.checkout_date, l.due_date, l.return_date, l.loan_status, l.renewal_count,
                   m.member_id, m.member_type, m.department_or_program, m.status AS member_status,
                   lb.branch_name, b.book_id, b.title, b.language, b.publication_year,
                   c.category_name, bc.copy_id, bc.availability_status, bc.condition_status,
                   lib.full_name AS checkout_librarian, lib.role AS checkout_role
            FROM loan l
            JOIN member m ON m.member_id = l.member_id
            JOIN book_copy bc ON bc.copy_id = l.copy_id
            JOIN book b ON b.book_id = bc.book_id
            JOIN category c ON c.category_id = b.category_id
            JOIN library_branch lb ON lb.branch_id = bc.branch_id
            JOIN librarian lib ON lib.librarian_id = l.checkout_librarian_id
        """,
        "looker_reservation_detail.csv": """
            SELECT r.reservation_id, r.reservation_date, r.expiry_date, r.reservation_status, r.queue_position,
                   m.member_type, m.department_or_program, b.book_id, b.title, c.category_name
            FROM reservation r
            JOIN member m ON m.member_id = r.member_id
            JOIN book b ON b.book_id = r.book_id
            JOIN category c ON c.category_id = b.category_id
        """,
        "looker_fine_detail.csv": """
            SELECT f.fine_id, f.assessed_date, f.fine_type, f.amount, f.paid_amount,
                   ROUND(f.amount - f.paid_amount, 2) AS outstanding_amount, f.fine_status,
                   m.member_type, b.title, c.category_name
            FROM fine f
            JOIN member m ON m.member_id = f.member_id
            JOIN loan l ON l.loan_id = f.loan_id
            JOIN book_copy bc ON bc.copy_id = l.copy_id
            JOIN book b ON b.book_id = bc.book_id
            JOIN category c ON c.category_id = b.category_id
        """,
    }
    for filename, query in views.items():
        rows = read_query(conn, query)
        write_csv(OUTPUT_DIR / filename, list(rows[0].keys()) if rows else [], rows)

    full_book_demand = read_query(
        conn,
        """
        WITH loan_counts AS (
            SELECT bc.book_id, COUNT(*) AS loan_count
            FROM loan l
            JOIN book_copy bc ON bc.copy_id = l.copy_id
            GROUP BY bc.book_id
        ),
        reservation_counts AS (
            SELECT book_id, COUNT(*) AS reservation_count
            FROM reservation
            GROUP BY book_id
        ),
        available_counts AS (
            SELECT book_id, SUM(CASE WHEN availability_status = 'available' THEN 1 ELSE 0 END) AS available_copies,
                   COUNT(*) AS total_copies
            FROM book_copy
            GROUP BY book_id
        )
        SELECT b.book_id, b.title, c.category_name,
               COALESCE(lc.loan_count, 0) AS loan_count,
               COALESCE(rc.reservation_count, 0) AS reservation_count,
               COALESCE(ac.available_copies, 0) AS available_copies,
               COALESCE(ac.total_copies, 0) AS total_copies,
               ROUND(COALESCE(rc.reservation_count, 0) * 2.2 + COALESCE(lc.loan_count, 0) * 0.55
                     - COALESCE(ac.available_copies, 0) * 1.5, 2) AS purchase_need_score
        FROM book b
        JOIN category c ON c.category_id = b.category_id
        LEFT JOIN loan_counts lc ON lc.book_id = b.book_id
        LEFT JOIN reservation_counts rc ON rc.book_id = b.book_id
        LEFT JOIN available_counts ac ON ac.book_id = b.book_id
        ORDER BY purchase_need_score DESC
        """,
    )
    write_csv(
        OUTPUT_DIR / "looker_book_demand.csv",
        [
            "book_id",
            "title",
            "category_name",
            "loan_count",
            "reservation_count",
            "available_copies",
            "total_copies",
            "purchase_need_score",
        ],
        full_book_demand,
    )
    write_csv(
        OUTPUT_DIR / "kpi_summary.csv",
        ["metric", "value"],
        [
            {"metric": "total_loans", "value": metrics["total_loans"]},
            {"metric": "active_loans", "value": metrics["active_loans"]},
            {"metric": "overdue_loans", "value": metrics["overdue_loans"]},
            {"metric": "overdue_rate_percent", "value": metrics["overdue_rate"]},
            {"metric": "available_copies", "value": metrics["available_copies"]},
            {"metric": "availability_rate_percent", "value": metrics["availability_rate"]},
            {"metric": "total_reservations", "value": metrics["total_reservations"]},
            {"metric": "waiting_reservations", "value": metrics["waiting_reservations"]},
            {"metric": "fine_balance", "value": round(metrics["fine_balance"], 2)},
            {"metric": "paid_fines", "value": round(metrics["paid_fines"], 2)},
        ],
    )


def markdown_table(rows: list[dict], columns: list[str]) -> str:
    header = "| " + " | ".join(columns) + " |"
    rule = "| " + " | ".join("---" for _ in columns) + " |"
    body = []
    for row in rows:
        body.append("| " + " | ".join(str(row.get(col, "")) for col in columns) + " |")
    return "\n".join([header, rule] + body)


def generate_report(metrics: dict, row_counts: dict[str, int]) -> None:
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    top_purchase = metrics["purchase_needs"][:5]
    top_borrowed = metrics["top_borrowed_books"][:5]
    branch_leader = metrics["loans_by_branch"][0]
    top_member_type = metrics["member_type_summary"][0]
    top_overdue_category = metrics["overdue_by_category"][0] if metrics["overdue_by_category"] else {
        "category_name": "No overdue category",
        "overdue_loans": 0,
    }
    report = f"""# {PROJECT_TITLE}

## 1. Title Page

- Course: {COURSE_NAME}
- Topic: Topic #11 - University Library
- Student: {STUDENT_NAME}
- University: {UNIVERSITY_NAME}
- Professor: {PROFESSOR_NAME}
- Delivery date: {DELIVERY_DATE}
- Report language: English
- Looker Studio dashboard link: To be added after publishing
- Telegram chatbot link/user name: To be added after publishing

## 2. Executive Summary

This project designs and analyzes a professional BI solution for the {PROJECT_TITLE}. The system manages members, books, physical copies, loans, reservations, fines, branches, librarians, publishers, authors, and categories. The management problem is to improve book availability, reduce overdue risk, identify purchase needs, monitor branch performance, and provide a reliable member-facing service channel.

The dataset is {DATA_POSITIONING}. It contains {row_counts['loan']:,} loan records, {row_counts['reservation']:,} reservation records, {row_counts['book_copy']:,} physical copies, {row_counts['book']:,} books, and {row_counts['member']:,} members. The dashboard shows {metrics['total_loans']:,} total loans, {metrics['overdue_loans']:,} currently overdue loans, an overdue rate of {metrics['overdue_rate']}% among open loans, {metrics['available_copies']:,} available copies, and an outstanding fine balance of {money(metrics['fine_balance'])}.

Key findings:

- Purchase decisions should prioritize high-demand titles with repeated reservations and low available copies.
- {branch_leader['branch_name']} has the highest loan volume with {branch_leader['loans']:,} loans, so staffing and copy allocation should be reviewed there first.
- {top_overdue_category['category_name']} has the largest overdue concentration among current overdue categories, with {top_overdue_category['overdue_loans']} open overdue loans.
- {top_member_type['member_type'].title()} members generate the highest loan volume with {top_member_type['loans']:,} loans, so communication and borrowing rules should be optimized for this user group.
- The Telegram chatbot should reduce operator workload by validating member IDs, book IDs, reservation rules, loan status, and fine balances before creating a request.

## 3. Introduction of the System and Stakeholders

The {PROJECT_TITLE} supports borrowing, reservation, inventory control, purchase planning, and fine management for a university environment. The project is designed for three stakeholder groups:

- Manager: needs strategic KPIs such as demand, overdue rate, fine balance, purchase needs, branch performance, and service quality.
- Analyst/operator: needs operational reports on active loans, overdue members, reservation queues, copy status, staff workload, and data quality.
- External user/member: needs book search, availability status, reservation status, active loans, due dates, and fine summaries.

## 4. Main Processes and Business Rules

Main processes:

1. Member registration and membership status control.
2. Book cataloging and physical copy inventory.
3. Loan checkout and return.
4. Reservation placement, queue management, and fulfillment.
5. Fine assessment and payment tracking.
6. Purchase-need analysis based on demand and availability.
7. Telegram chatbot request intake and validation.

Important rules:

- A member must be active to borrow or reserve books.
- A loan is created for a physical copy, while a reservation is created for a title.
- A reference-only copy cannot be borrowed.
- due_date must be after checkout_date.
- A returned loan must have a return_date.
- Waiting reservations must have a queue position.
- paid_amount cannot be greater than amount.
- The chatbot must reject incomplete, illogical, or inconsistent requests and explain the correction needed.

## 5. Data Model: Entities, Attributes, Keys, Relationships, and ERD

The model has 12 entities: LibraryBranch, Member, Librarian, Publisher, Category, Author, Book, BookAuthor, BookCopy, Loan, Reservation, and Fine.

Primary relationships:

- One branch has many members, librarians, and book copies.
- One publisher publishes many books.
- One category classifies many books.
- Books and authors have a many-to-many relationship through BookAuthor.
- One book has many physical copies.
- One member has many loans, reservations, and fines.
- One loan is linked to one member and one physical copy.
- One reservation is linked to one member and one book title.
- One fine is linked to one member and one loan.

The complete ERD and full table dictionary are in `erd_table_structure.md`.

## 6. Data Generation Method and Quality Control

The data was generated as a close-to-real assumed dataset for the course project. It is designed to behave like a real library export while avoiding private personal information. The generation uses fixed business rules, deterministic IDs, realistic date ranges, realistic status distributions, and referential integrity checks.

Data volume:

{markdown_table([{'table': k, 'rows': v} for k, v in row_counts.items()], ['table', 'rows'])}

Quality controls:

- All primary keys are unique.
- All foreign keys point to valid records.
- Dates follow the correct sequence.
- Loan status matches return_date logic.
- Waiting reservations have queue positions.
- Fine payment amounts do not exceed assessed amounts.
- Dashboard outputs are calculated from the generated database, not manually typed.
- Looker-ready exports are generated from joined analytical views, so the dashboard can be built without manually joining all 12 tables.

## 7. Looker Studio Dashboard Description

The Looker Studio dashboard should have three professional pages: Manager, Analyst/Operator, and External User. The recommended data sources are `looker_loan_detail.csv`, `looker_reservation_detail.csv`, `looker_fine_detail.csv`, `looker_book_demand.csv`, and `kpi_summary.csv`.

Manager page:

- KPI cards: total loans, overdue rate, available copies, outstanding fine balance.
- Time trend: monthly loans.
- Ranking table: purchase-need score by book.
- Bar chart: loans by branch.
- Donut chart: reservation status.
- Management analysis text box: recommended purchase and branch actions.

Analyst/operator page:

- KPI cards: active loans, overdue loans, waiting reservations.
- Bar chart: overdue loans by category.
- Table: active or overdue loans with member type, book, due date, and branch.
- Bar chart: processed loans by librarian.
- Filter controls: date range, branch, category, member type, loan status.
- Data-quality table: suspicious or inconsistent records to investigate.

External user/member page:

- Search-style table: book availability by title/category.
- KPI card: available copies.
- Table: sample member loan status.
- Table: sample member unpaid fines.
- Filter controls: category, language, audience, availability status.
- Member guidance panel: what to do if a title is unavailable or a fine is unpaid.

Every chart should include title, unit of measurement, and a one-line explanation.

## 8. Reports Needed by Each Role

Manager reports:

- Purchase needs by title and category.
- Monthly borrowing trend.
- Branch performance and copy availability.
- Fine balance and payment trend.
- High-risk categories for overdue monitoring.

Analyst/operator reports:

- Active and overdue loans.
- Reservation queue and ready-for-pickup list.
- Copy condition and maintenance list.
- Librarian checkout workload.
- Member accounts blocked by expired membership, suspension, or unpaid fines.

External user reports:

- Available copies by book.
- Reservation status.
- Active loans and due dates.
- Unpaid fine summary.
- Lost/damaged book request tracking.

## 9. Telegram Chatbot Design

Roles:

- Manager: asks for KPIs and purchase recommendations.
- Analyst/operator: checks member/copy status and validates operational entries.
- External user/member: searches, reserves, checks loans, and checks fines.

Required scenarios:

1. Search for a book by title, author, or category.
2. Reserve a book after checking membership and inventory.
3. Check active and overdue loan status.
4. Report a lost or damaged book.
5. Ask about unpaid fines.
6. Manager asks for purchase-need recommendations.
7. Analyst checks whether an entered member/book/loan combination is valid.

Validation rules:

- Member ID must exist.
- Member must be active for new borrowing/reservation.
- Book ID must exist.
- Duplicate active reservations should be rejected.
- Suspended or expired members should receive a correction message.
- Fine amounts and dates must be logical.
- The bot must return a tracking number or clear summary after each valid request.

The detailed chatbot design is in `chatbot_design.md`, the core validation logic is in `library_chatbot.py`, and the Telegram wrapper is in `telegram_bot.py`.

## 10. Final Analysis, Limitations, and Suggestions

Top borrowed books:

{markdown_table(top_borrowed, ['title', 'category_name', 'loans'])}

Highest purchase-need candidates:

{markdown_table(top_purchase, ['title', 'category_name', 'loan_count', 'reservation_count', 'available_copies', 'purchase_need_score'])}

Management interpretation:

- Purchase recommendations: prioritize the top purchase-need titles because they combine high borrowing demand, reservation pressure, and limited availability.
- Overdue risk: focus reminders on {top_overdue_category['category_name']} and other categories with concentrated overdue loans.
- Branch performance: compare branch workload before assigning staff or transferring copies; {branch_leader['branch_name']} currently carries the highest loan volume.
- Member behavior: {top_member_type['member_type'].title()} users are the largest borrowing segment, so policies, reminders, and chatbot examples should be optimized for them.
- Service improvement: use the Telegram chatbot as the first validation layer for reservations, loan checks, lost/damaged reports, and fine inquiries.

Limitations:

- The dataset is close-to-real assumed course data, not an official Sharif University library export.
- Personal data is privacy-safe project data.
- Looker Studio must be connected through Google Sheets or uploaded CSV files using the provided exports.
- Telegram deployment requires creating a bot token with BotFather and hosting the script in Colab, a server, or another always-on environment.

Suggestions:

- Add live integration with the real university library management system.
- Add automatic overdue reminders.
- Use reservation demand to create purchase orders.
- Add branch-level inventory transfer recommendations.
- Add a member-facing Telegram chatbot link inside the library website or student portal.
"""
    (REPORT_DIR / "final_report.md").write_text(report, encoding="utf-8")
    html_report = markdown_to_simple_html(report, f"{PROJECT_TITLE} Report")
    (REPORT_DIR / "final_report.html").write_text(html_report, encoding="utf-8")


def markdown_to_simple_html(markdown: str, title: str) -> str:
    lines = markdown.splitlines()
    output = []
    in_list = False
    in_table = False
    table_rows = []

    def flush_list() -> None:
        nonlocal in_list
        if in_list:
            output.append("</ul>")
            in_list = False

    def flush_table() -> None:
        nonlocal in_table, table_rows
        if not in_table:
            return
        output.append("<table>")
        for idx, row in enumerate(table_rows):
            cells = [cell.strip() for cell in row.strip("|").split("|")]
            if idx == 1 and all(set(cell) <= {"-"} for cell in cells):
                continue
            tag = "th" if idx == 0 else "td"
            output.append("<tr>" + "".join(f"<{tag}>{html.escape(cell)}</{tag}>" for cell in cells) + "</tr>")
        output.append("</table>")
        in_table = False
        table_rows = []

    for line in lines:
        if line.startswith("|") and line.endswith("|"):
            flush_list()
            in_table = True
            table_rows.append(line)
            continue
        flush_table()
        if line.startswith("# "):
            flush_list()
            output.append(f"<h1>{html.escape(line[2:])}</h1>")
        elif line.startswith("## "):
            flush_list()
            output.append(f"<h2>{html.escape(line[3:])}</h2>")
        elif line.startswith("### "):
            flush_list()
            output.append(f"<h3>{html.escape(line[4:])}</h3>")
        elif line.startswith("- "):
            if not in_list:
                output.append("<ul>")
                in_list = True
            output.append(f"<li>{html.escape(line[2:])}</li>")
        elif line.strip():
            flush_list()
            output.append(f"<p>{html.escape(line)}</p>")
        else:
            flush_list()
    flush_list()
    flush_table()
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{html.escape(title)}</title>
  <style>
    body {{ font-family: Arial, sans-serif; line-height: 1.55; margin: 0; color: #1f2933; background: #f6f7f9; }}
    main {{ max-width: 980px; margin: 0 auto; padding: 32px 20px 60px; background: white; }}
    h1 {{ font-size: 30px; margin-bottom: 18px; }}
    h2 {{ font-size: 22px; border-top: 1px solid #d9dee5; padding-top: 22px; margin-top: 28px; }}
    h3 {{ font-size: 18px; }}
    table {{ border-collapse: collapse; width: 100%; margin: 14px 0; font-size: 14px; }}
    th, td {{ border: 1px solid #d5dbe3; padding: 8px 10px; text-align: left; }}
    th {{ background: #eef2f6; }}
    code {{ background: #eef2f6; padding: 2px 4px; }}
  </style>
</head>
<body><main>{''.join(output)}</main></body></html>"""


def table_html(rows: list[dict], columns: list[str]) -> str:
    head = "".join(f"<th>{html.escape(col.replace('_', ' ').title())}</th>" for col in columns)
    body = []
    for row in rows:
        body.append("<tr>" + "".join(f"<td>{html.escape(str(row.get(col, '')))}</td>" for col in columns) + "</tr>")
    return f"<table><thead><tr>{head}</tr></thead><tbody>{''.join(body)}</tbody></table>"


def bars_html(rows: list[dict], label: str, value: str, unit: str = "") -> str:
    max_value = max((float(row[value]) for row in rows), default=1)
    bars = []
    palette = ["#2563eb", "#059669", "#d97706", "#7c3aed", "#dc2626", "#0891b2"]
    for idx, row in enumerate(rows):
        width = max(3, float(row[value]) / max_value * 100)
        bars.append(
            f"""
            <div class="bar-row">
              <div class="bar-label">{html.escape(str(row[label]))}</div>
              <div class="bar-track"><div class="bar-fill" style="width:{width:.1f}%;background:{palette[idx % len(palette)]}"></div></div>
              <div class="bar-value">{html.escape(str(row[value]))}{html.escape(unit)}</div>
            </div>
            """
        )
    return "".join(bars)


def generate_dashboard(metrics: dict) -> None:
    DASHBOARD_DIR.mkdir(parents=True, exist_ok=True)
    month_rows = metrics["loans_by_month"][-12:]
    branch_leader = metrics["loans_by_branch"][0]
    top_member_type = metrics["member_type_summary"][0]
    top_purchase = metrics["purchase_needs"][0]
    html_doc = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{PROJECT_TITLE} Dashboard Preview</title>
  <style>
    :root {{
      --ink:#17202a; --muted:#5d6b7a; --line:#d7dde5; --paper:#ffffff; --bg:#eef2f5;
      --navy:#101928; --blue:#2563eb; --green:#008a67; --amber:#c77913; --red:#c24132; --cyan:#0f8195;
    }}
    * {{ box-sizing:border-box; }}
    body {{ margin:0; font-family:Arial, sans-serif; background:var(--bg); color:var(--ink); }}
    header {{ background:var(--navy); color:white; padding:26px 32px 22px; }}
    header .meta {{ display:flex; gap:10px; flex-wrap:wrap; margin-top:16px; }}
    header h1 {{ margin:0 0 8px; font-size:30px; line-height:1.18; letter-spacing:0; }}
    header p {{ margin:0; color:#d7dee8; max-width:960px; }}
    .chip {{ border:1px solid rgba(255,255,255,.24); color:#f5f7fb; padding:7px 10px; border-radius:6px; font-size:13px; }}
    nav {{ display:flex; gap:8px; flex-wrap:wrap; padding:14px 32px; background:white; border-bottom:1px solid var(--line); position:sticky; top:0; z-index:5; }}
    nav a {{ color:#172033; text-decoration:none; border:1px solid var(--line); padding:8px 12px; border-radius:6px; font-size:14px; background:#fbfcfd; }}
    main {{ max-width:1240px; margin:0 auto; padding:26px 22px 44px; }}
    section {{ margin:0 0 30px; padding:6px 0 0; }}
    .section-head {{ display:flex; justify-content:space-between; gap:16px; align-items:flex-end; margin:0 0 14px; }}
    .section-head p {{ margin:5px 0 0; color:var(--muted); font-size:14px; }}
    h2 {{ margin:0; font-size:24px; letter-spacing:0; }}
    h3 {{ margin:0 0 10px; font-size:16px; }}
    .kpis {{ display:grid; grid-template-columns:repeat(4, minmax(0, 1fr)); gap:12px; margin-bottom:16px; }}
    .kpi {{ background:var(--paper); border:1px solid var(--line); border-radius:8px; padding:15px; min-height:104px; box-shadow:0 1px 2px rgba(16,24,40,.04); }}
    .kpi .label {{ color:var(--muted); font-size:12px; text-transform:uppercase; letter-spacing:.04em; }}
    .kpi .value {{ font-size:28px; font-weight:700; margin-top:9px; }}
    .kpi .note {{ margin-top:8px; }}
    .grid {{ display:grid; grid-template-columns:1fr 1fr; gap:16px; }}
    .panel {{ background:var(--paper); border:1px solid var(--line); border-radius:8px; padding:16px; box-shadow:0 1px 2px rgba(16,24,40,.04); }}
    .panel.accent {{ border-left:4px solid var(--blue); }}
    .panel.success {{ border-left:4px solid var(--green); }}
    .panel.warning {{ border-left:4px solid var(--amber); }}
    .panel.risk {{ border-left:4px solid var(--red); }}
    .note {{ color:var(--muted); font-size:13px; margin:7px 0 0; }}
    .insights {{ display:grid; grid-template-columns:repeat(3, minmax(0, 1fr)); gap:12px; margin:0 0 16px; }}
    .insight-title {{ color:var(--muted); font-size:12px; text-transform:uppercase; letter-spacing:.04em; margin-bottom:6px; }}
    .insight-value {{ font-weight:700; font-size:17px; }}
    .bar-row {{ display:grid; grid-template-columns:190px 1fr 76px; gap:10px; align-items:center; margin:8px 0; font-size:13px; }}
    .bar-track {{ height:12px; background:#edf1f5; border-radius:3px; overflow:hidden; }}
    .bar-fill {{ height:100%; }}
    .bar-value {{ text-align:right; color:var(--muted); }}
    table {{ width:100%; border-collapse:collapse; font-size:13px; }}
    th, td {{ border:1px solid var(--line); padding:8px; text-align:left; vertical-align:top; }}
    th {{ background:#edf1f5; color:#2d3745; }}
    .table-wrap {{ overflow-x:auto; }}
    @media (max-width: 800px) {{
      header {{ padding:22px 18px; }}
      nav {{ padding:12px 18px; }}
      .kpis, .grid, .insights {{ grid-template-columns:1fr; }}
      .section-head {{ display:block; }}
      .bar-row {{ grid-template-columns:1fr; gap:4px; }}
      .bar-value {{ text-align:left; }}
    }}
  </style>
</head>
<body>
  <header>
    <h1>{PROJECT_TITLE}</h1>
    <p>Professional BI dashboard preview for {UNIVERSITY_NAME}. The production version should be recreated in Looker Studio with the exported CSV or Google Sheets data sources.</p>
    <div class="meta">
      <span class="chip">{COURSE_NAME}</span>
      <span class="chip">{STUDENT_NAME}</span>
      <span class="chip">{PROFESSOR_NAME}</span>
      <span class="chip">Delivery: {DELIVERY_DATE}</span>
    </div>
  </header>
  <nav>
    <a href="#manager">Manager</a>
    <a href="#analyst">Analyst</a>
    <a href="#external">External User</a>
    <a href="#looker">Looker Studio</a>
  </nav>
  <main>
    <section id="manager">
      <div class="section-head">
        <div>
          <h2>Manager Page</h2>
          <p>Strategic view for demand, risk, branch workload, and purchase planning.</p>
        </div>
      </div>
      <div class="kpis">
        <div class="kpi"><div class="label">Total loans</div><div class="value">{metrics['total_loans']:,}</div><div class="note">Unit: loan records</div></div>
        <div class="kpi"><div class="label">Overdue rate</div><div class="value">{metrics['overdue_rate']}%</div><div class="note">Unit: percent of open loans</div></div>
        <div class="kpi"><div class="label">Available copies</div><div class="value">{metrics['available_copies']:,}</div><div class="note">Unit: physical copies</div></div>
        <div class="kpi"><div class="label">Outstanding fine balance</div><div class="value">{money(metrics['fine_balance'])}</div><div class="note">Unit: fine amount</div></div>
      </div>
      <div class="insights">
        <div class="panel accent"><div class="insight-title">Top purchase candidate</div><div class="insight-value">{html.escape(top_purchase['title'])}</div><p class="note">Demand score: {top_purchase['purchase_need_score']}</p></div>
        <div class="panel success"><div class="insight-title">Highest branch workload</div><div class="insight-value">{html.escape(branch_leader['branch_name'])}</div><p class="note">{branch_leader['loans']:,} loans processed</p></div>
        <div class="panel warning"><div class="insight-title">Largest user segment</div><div class="insight-value">{html.escape(top_member_type['member_type'].title())}</div><p class="note">{top_member_type['loans']:,} loans generated</p></div>
      </div>
      <div class="grid">
        <div class="panel">
          <h3>Monthly Borrowing Trend</h3>
          {bars_html(month_rows, 'month', 'loans')}
          <p class="note">Shows whether circulation demand is increasing or decreasing over time.</p>
        </div>
        <div class="panel">
          <h3>Loans by Branch</h3>
          {bars_html(metrics['loans_by_branch'], 'branch_name', 'loans')}
          <p class="note">Compares branch workload and demand.</p>
        </div>
      </div>
      <div class="panel warning" style="margin-top:16px">
        <h3>Purchase Need Ranking</h3>
        <div class="table-wrap">{table_html(metrics['purchase_needs'][:8], ['title', 'category_name', 'loan_count', 'reservation_count', 'available_copies', 'purchase_need_score'])}</div>
        <p class="note">Higher scores indicate high reservation pressure, frequent borrowing, and low availability.</p>
      </div>
    </section>

    <section id="analyst">
      <div class="section-head">
        <div>
          <h2>Analyst / Operator Page</h2>
          <p>Operational control view for daily circulation follow-up, staff workload, and queue management.</p>
        </div>
      </div>
      <div class="kpis">
        <div class="kpi"><div class="label">Active loans</div><div class="value">{metrics['active_loans']:,}</div><div class="note">Unit: open loans</div></div>
        <div class="kpi"><div class="label">Overdue loans</div><div class="value">{metrics['overdue_loans']:,}</div><div class="note">Unit: open overdue loans</div></div>
        <div class="kpi"><div class="label">Waiting reservations</div><div class="value">{metrics['waiting_reservations']:,}</div><div class="note">Unit: reservation requests</div></div>
        <div class="kpi"><div class="label">Returned loans</div><div class="value">{metrics['returned_loans']:,}</div><div class="note">Unit: completed loans</div></div>
      </div>
      <div class="grid">
        <div class="panel risk">
          <h3>Overdue Loans by Category</h3>
          {bars_html(metrics['overdue_by_category'], 'category_name', 'overdue_loans')}
          <p class="note">Helps operators focus reminders and follow-up.</p>
        </div>
        <div class="panel">
          <h3>Librarian Checkout Workload</h3>
          {bars_html(metrics['operator_performance'], 'full_name', 'processed_loans')}
          <p class="note">Measures processed checkout volume by librarian.</p>
        </div>
      </div>
    </section>

    <section id="external">
      <div class="section-head">
        <div>
          <h2>External User / Member Page</h2>
          <p>Member-facing view for availability, reservation visibility, and self-service fine awareness.</p>
        </div>
      </div>
      <div class="kpis">
        <div class="kpi"><div class="label">Book availability rate</div><div class="value">{metrics['availability_rate']}%</div><div class="note">Unit: available copies / total copies</div></div>
        <div class="kpi"><div class="label">Total reservations</div><div class="value">{metrics['total_reservations']:,}</div><div class="note">Unit: reservations</div></div>
        <div class="kpi"><div class="label">Paid fines</div><div class="value">{money(metrics['paid_fines'])}</div><div class="note">Unit: fine amount</div></div>
        <div class="kpi"><div class="label">Lost loans</div><div class="value">{metrics['lost_loans']:,}</div><div class="note">Unit: loan records</div></div>
      </div>
      <div class="grid">
        <div class="panel">
          <h3>Reservation Status</h3>
          {bars_html(metrics['reservation_status'], 'reservation_status', 'reservations')}
          <p class="note">Shows whether requests are fulfilled, waiting, cancelled, or expired.</p>
        </div>
        <div class="panel">
          <h3>Member Type Usage</h3>
          {bars_html(metrics['member_type_summary'], 'member_type', 'loans')}
          <p class="note">Shows which user groups create most borrowing demand.</p>
        </div>
      </div>
      <div class="panel success" style="margin-top:16px">
        <h3>Most Borrowed Titles</h3>
        <div class="table-wrap">{table_html(metrics['top_borrowed_books'][:8], ['title', 'category_name', 'loans'])}</div>
        <p class="note">Useful for public search pages and recommendation lists.</p>
      </div>
    </section>

    <section id="looker">
      <div class="section-head">
        <div>
          <h2>Looker Studio Production Setup</h2>
          <p>Recreate this preview in Looker Studio using the exported analytical CSV files.</p>
        </div>
      </div>
      <div class="grid">
        <div class="panel accent">
          <h3>Recommended Data Sources</h3>
          <p class="note">Upload these files to Google Sheets, then connect each sheet to Looker Studio.</p>
          <div class="table-wrap">
            <table>
              <tr><th>File</th><th>Use</th></tr>
              <tr><td>looker_loan_detail.csv</td><td>Loan trend, branch workload, overdue analysis, librarian performance</td></tr>
              <tr><td>looker_reservation_detail.csv</td><td>Reservation status, demand queue, member request patterns</td></tr>
              <tr><td>looker_fine_detail.csv</td><td>Fine balance, paid amount, outstanding amount</td></tr>
              <tr><td>looker_book_demand.csv</td><td>Purchase need ranking and availability table</td></tr>
              <tr><td>kpi_summary.csv</td><td>Executive KPI cards</td></tr>
            </table>
          </div>
        </div>
        <div class="panel warning">
          <h3>Professional Delivery Notes</h3>
          <p class="note">Use a date range control, branch filter, category filter, member type filter, and role-specific pages. Each chart needs a title, unit of measurement, and one-sentence interpretation.</p>
          <p class="note">Share the final Looker Studio dashboard with edit/view access for the instructor before submitting.</p>
        </div>
      </div>
    </section>
  </main>
</body>
</html>"""
    (DASHBOARD_DIR / "dashboard_preview.html").write_text(html_doc, encoding="utf-8")


def generate_dashboard_blueprint() -> None:
    blueprint = f"""# Looker Studio Dashboard Blueprint

Project: {PROJECT_TITLE}
Student: {STUDENT_NAME}
Course: {COURSE_NAME}
University: {UNIVERSITY_NAME}
Professor: {PROFESSOR_NAME}

## Data Source Setup

Upload these files from `outputs/` to Google Sheets, then connect each Sheet to Looker Studio:

| File | Looker data source name | Main use |
|---|---|---|
| looker_loan_detail.csv | Loan Detail | Loan trend, overdue risk, branch performance, operator workload |
| looker_reservation_detail.csv | Reservation Detail | Reservation queue, request status, category demand |
| looker_fine_detail.csv | Fine Detail | Fine balance, payment status, financial exposure |
| looker_book_demand.csv | Book Demand | Purchase recommendations, availability, high-demand books |
| kpi_summary.csv | KPI Summary | Optional executive KPI lookup table |

Recommended report controls:

- Date range control: `checkout_date` for Loan Detail.
- Drop-down filter: `branch_name`.
- Drop-down filter: `category_name`.
- Drop-down filter: `member_type`.
- Drop-down filter: `loan_status`.
- Optional filter: `checkout_librarian`.

## Calculated Fields

Create these calculated fields in Looker Studio where useful:

| Field | Formula idea | Source |
|---|---|---|
| Loan Count | `COUNT_DISTINCT(loan_id)` | Loan Detail |
| Active Loan Count | count where `loan_status = active` | Loan Detail |
| Overdue Loan Count | count where `loan_status = overdue` | Loan Detail |
| Overdue Rate | `Overdue Loan Count / (Active Loan Count + Overdue Loan Count)` | Loan Detail |
| Outstanding Fine | `SUM(outstanding_amount)` | Fine Detail |
| Availability Rate | `SUM(available_copies) / SUM(total_copies)` | Book Demand |
| Purchase Need Score | existing field `purchase_need_score` | Book Demand |

## Page 1: Manager

Purpose: strategic decision-making for collection investment, risk, and branch performance.

Charts:

| # | Chart | Data source | Dimension | Metric | Unit | Management question |
|---|---|---|---|---|---|---|
| 1 | KPI card | Loan Detail | none | Loan Count | loans | How much is the library used? |
| 2 | KPI card | Loan Detail | none | Overdue Rate | percent | How serious is circulation risk? |
| 3 | KPI card | Book Demand | none | SUM(available_copies) | copies | How much stock is immediately usable? |
| 4 | KPI card | Fine Detail | none | Outstanding Fine | amount | How much fine balance is unpaid? |
| 5 | Time series | Loan Detail | checkout_date by month | Loan Count | loans/month | What is the borrowing trend? |
| 6 | Bar chart | Loan Detail | branch_name | Loan Count | loans | Which branch has the highest workload? |
| 7 | Ranking table | Book Demand | title, category_name | purchase_need_score, reservation_count, available_copies | score/count | Which books should be purchased first? |
| 8 | Donut chart | Reservation Detail | reservation_status | COUNT_DISTINCT(reservation_id) | reservations | Are requests fulfilled or stuck? |

Manager text insight box:

- Prioritize books with high purchase need score.
- Review staffing and copy allocation for the branch with highest loan volume.
- Track overdue categories weekly.
- Use reservations as early evidence of unmet demand.

## Page 2: Analyst / Operator

Purpose: daily operational control.

Charts:

| # | Chart | Data source | Dimension | Metric | Unit | Operational question |
|---|---|---|---|---|---|---|
| 1 | KPI card | Loan Detail | none | Active Loan Count | loans | How many loans are still open? |
| 2 | KPI card | Loan Detail | none | Overdue Loan Count | loans | How many need follow-up? |
| 3 | KPI card | Reservation Detail | none | waiting reservations | reservations | How large is the current queue? |
| 4 | Bar chart | Loan Detail | category_name | Overdue Loan Count | loans | Which category needs reminders? |
| 5 | Table | Loan Detail | loan_id, title, member_type, branch_name, due_date | loan_status | rows | Which loans should staff handle today? |
| 6 | Bar chart | Loan Detail | checkout_librarian | Loan Count | loans | How is operator workload distributed? |
| 7 | Table | Book Demand | title, category_name, available_copies, total_copies | purchase_need_score | rows | Which books have stock pressure? |

## Page 3: External User / Member

Purpose: member-facing visibility and self-service support.

Charts:

| # | Chart | Data source | Dimension | Metric | Unit | User question |
|---|---|---|---|---|---|---|
| 1 | KPI card | Book Demand | none | Availability Rate | percent | Are books generally available? |
| 2 | Search table | Book Demand | title, category_name | available_copies, total_copies | copies | Is a desired book available? |
| 3 | Table | Reservation Detail | title, reservation_status | COUNT_DISTINCT(reservation_id) | reservations | What is the reservation situation? |
| 4 | Table | Fine Detail | fine_type, fine_status | SUM(outstanding_amount) | amount | Are there unpaid fines? |
| 5 | Bar chart | Loan Detail | member_type | Loan Count | loans | Which user group uses the library most? |

## Visual Style

- Use a modern professional theme: white background, dark navy headers, restrained blue/green/amber accents.
- Keep pages dense and operational, not like a marketing page.
- Use consistent number formatting: counts as whole numbers, rates as percentages, fines with two decimals.
- Every chart must have a title, unit of measurement, and one-sentence interpretation.
- Share the final report with view access for {PROFESSOR_NAME}.
"""
    (ROOT / "dashboard_blueprint.md").write_text(blueprint, encoding="utf-8")


def generate_chatbot_files() -> None:
    design = f"""# Telegram Chatbot Design

Project: {PROJECT_TITLE}
Platform: Telegram
Core file: `library_chatbot.py`
Telegram wrapper: `telegram_bot.py`

## Roles

- Manager: asks about KPIs, purchase needs, overdue risks, and branch performance.
- Analyst/operator: validates member IDs, loan status, copy availability, and reservation requests.
- External user/member: searches books, reserves books, checks loans, reports lost/damaged books, and checks fines.

## Telegram Command Map

| Command | Role | Example | Validation |
|---|---|---|---|
| `/start` | all | `/start` | Introduces allowed commands |
| `/search` | external user | `/search database` | Search text required |
| `/reserve` | external user | `/reserve M000001 B000001` | Member exists, active, not expired, book exists, no duplicate reservation, fine balance acceptable |
| `/loans` | external user/operator | `/loans M000001` | Member exists |
| `/fines` | external user/operator | `/fines M000001` | Member exists |
| `/report_issue` | external user/operator | `/report_issue M000001 LN000123 damaged` | Member exists, loan exists, loan belongs to member, status allows issue report |
| `/purchase_needs` | manager | `/purchase_needs` | Returns top purchase candidates |
| `/kpis` | manager | `/kpis` | Returns management KPI summary |

## Scenario 1: Book Search

Input fields:

- Search text: title, category, or author keyword.
- Optional language/category filter.

Validation:

- Search text must not be empty.
- Result must match title, category, or author.

Output:

- Matching titles.
- Available copy count.
- Category and language.
- Telegram response includes up to 5 matching books so the message stays readable.

## Scenario 2: Reserve Book

Input fields:

- member_id.
- book_id.

Validation:

- member_id exists.
- member status is active.
- membership is not expired.
- book_id exists.
- member does not already have a waiting/ready reservation for the same book.
- member has no serious unpaid fine balance.

Success response:

- Reservation tracking number.
- Queue position or ready message.

Error response:

- Clear reason and correction request.

## Scenario 3: Check Loan Status

Input fields:

- member_id.

Validation:

- member_id exists.

Output:

- Active loans.
- Overdue loans.
- Due dates.
- Book titles.

## Scenario 4: Report Lost or Damaged Book

Input fields:

- member_id.
- loan_id.
- issue_type: lost or damaged.

Validation:

- member_id exists.
- loan_id exists.
- loan belongs to member.
- loan is active or overdue.
- issue_type is valid.

Output:

- Tracking number.
- Review/fine estimate.
- Next step.

## Scenario 5: Check Fines

Input fields:

- member_id.

Validation:

- member_id exists.

Output:

- Total assessed fines.
- Paid amount.
- Outstanding amount.
- Fine details.

## Scenario 6: Manager KPI Request

Input:

- `/kpis`

Output:

- Total loans.
- Active loans.
- Overdue loans.
- Available copies.
- Fine balance.
- Waiting reservations.

## Scenario 7: Purchase Recommendation Request

Input:

- `/purchase_needs`

Output:

- Top books by purchase_need_score.
- Loan count.
- Reservation count.
- Available copies.

## Sample Dialogue

User: I want to reserve book B000027. My member ID is M000104.

Bot:

1. Checks member M000104 exists.
2. Checks membership status is active.
3. Checks unpaid fine balance.
4. Checks book B000027 exists.
5. Checks duplicate active reservations.

If valid:

Your reservation was accepted. Tracking number: RSV-20260708-104-027. The title has 2 available copies and your request has been recorded.

If invalid:

This reservation cannot be completed because your membership status is expired. Please renew your membership and try again.

## Technical Implementation

The Telegram bot uses long polling through the official Telegram Bot API. To run it:

1. Create a bot in Telegram using BotFather.
2. Copy the bot token.
3. Set the environment variable `TELEGRAM_BOT_TOKEN`.
4. Run `python telegram_bot.py`.

In Google Colab, use:

```python
import os
os.environ["TELEGRAM_BOT_TOKEN"] = "PASTE_TOKEN_HERE"
!python telegram_bot.py
```

For final submission, include the Telegram bot username or link in the report title page.
"""
    (ROOT / "chatbot_design.md").write_text(design, encoding="utf-8")

    chatbot_code = r'''from __future__ import annotations

import csv
from datetime import date
from pathlib import Path


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
TODAY = date(2026, 7, 8)


def load_csv(name):
    with (DATA_DIR / f"{name}.csv").open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def load_data():
    data = {
        "member": load_csv("member"),
        "book": load_csv("book"),
        "book_copy": load_csv("book_copy"),
        "loan": load_csv("loan"),
        "reservation": load_csv("reservation"),
        "fine": load_csv("fine"),
        "category": load_csv("category"),
    }
    return data


def by_id(rows, key):
    return {row[key]: row for row in rows}


def member_fine_balance(data, member_id):
    total = 0.0
    for fine in data["fine"]:
        if fine["member_id"] == member_id and fine["fine_status"] != "waived":
            total += float(fine["amount"] or 0) - float(fine["paid_amount"] or 0)
    return round(total, 2)


def available_copies(data, book_id):
    return [
        copy for copy in data["book_copy"]
        if copy["book_id"] == book_id and copy["availability_status"] == "available" and copy["is_reference_only"] == "0"
    ]


def search_books(data, text):
    text = text.strip().lower()
    if not text:
        return {"ok": False, "message": "Search text is required."}
    categories = by_id(data["category"], "category_id")
    results = []
    for book in data["book"]:
        category = categories[book["category_id"]]["category_name"]
        haystack = f"{book['book_id']} {book['title']} {category} {book['language']}".lower()
        if text in haystack:
            results.append({
                "book_id": book["book_id"],
                "title": book["title"],
                "category": category,
                "language": book["language"],
                "available_copies": len(available_copies(data, book["book_id"])),
            })
    if not results:
        return {"ok": False, "message": "No matching books were found."}
    return {"ok": True, "results": results[:10]}


def reserve_book(data, member_id, book_id):
    members = by_id(data["member"], "member_id")
    books = by_id(data["book"], "book_id")
    if member_id not in members:
        return {"ok": False, "message": "Member ID was not found. Please check the ID."}
    member = members[member_id]
    if member["status"] != "active":
        return {"ok": False, "message": f"Reservation rejected because member status is {member['status']}."}
    if date.fromisoformat(member["expiry_date"]) < TODAY:
        return {"ok": False, "message": "Reservation rejected because membership is expired."}
    if book_id not in books:
        return {"ok": False, "message": "Book ID was not found. Please check the ID."}
    for reservation in data["reservation"]:
        if (
            reservation["member_id"] == member_id
            and reservation["book_id"] == book_id
            and reservation["reservation_status"] in {"waiting", "ready_for_pickup"}
        ):
            return {"ok": False, "message": "Duplicate reservation rejected. This member already has an active reservation for the book."}
    fine_balance = member_fine_balance(data, member_id)
    if fine_balance > 35:
        return {"ok": False, "message": f"Reservation rejected because outstanding fines are {fine_balance:.2f}."}
    copies = available_copies(data, book_id)
    tracking = f"RSV-{TODAY.strftime('%Y%m%d')}-{member_id[-3:]}-{book_id[-3:]}"
    if copies:
        return {"ok": True, "tracking": tracking, "message": f"Reservation accepted. {len(copies)} available copy/copies found. Tracking number: {tracking}."}
    return {"ok": True, "tracking": tracking, "message": f"No available copy right now, but the reservation was added to the waiting queue. Tracking number: {tracking}."}


def check_loan_status(data, member_id):
    members = by_id(data["member"], "member_id")
    if member_id not in members:
        return {"ok": False, "message": "Member ID was not found."}
    copies = by_id(data["book_copy"], "copy_id")
    books = by_id(data["book"], "book_id")
    rows = []
    for loan in data["loan"]:
        if loan["member_id"] == member_id and loan["loan_status"] in {"active", "overdue", "lost"}:
            copy = copies[loan["copy_id"]]
            book = books[copy["book_id"]]
            rows.append({
                "loan_id": loan["loan_id"],
                "title": book["title"],
                "due_date": loan["due_date"],
                "status": loan["loan_status"],
            })
    return {"ok": True, "member_id": member_id, "open_loans": rows}


def report_lost_or_damaged(data, member_id, loan_id, issue_type):
    if issue_type not in {"lost", "damaged"}:
        return {"ok": False, "message": "Issue type must be lost or damaged."}
    members = by_id(data["member"], "member_id")
    if member_id not in members:
        return {"ok": False, "message": "Member ID was not found."}
    loans = by_id(data["loan"], "loan_id")
    if loan_id not in loans:
        return {"ok": False, "message": "Loan ID was not found."}
    loan = loans[loan_id]
    if loan["member_id"] != member_id:
        return {"ok": False, "message": "Loan does not belong to this member."}
    if loan["loan_status"] not in {"active", "overdue"}:
        return {"ok": False, "message": f"Only active or overdue loans can be reported. Current status is {loan['loan_status']}."}
    tracking = f"CASE-{TODAY.strftime('%Y%m%d')}-{loan_id[-4:]}"
    return {"ok": True, "tracking": tracking, "message": f"{issue_type.title()} item report received. Tracking number: {tracking}. Library staff must review the copy and confirm any fine."}


def check_fines(data, member_id):
    members = by_id(data["member"], "member_id")
    if member_id not in members:
        return {"ok": False, "message": "Member ID was not found."}
    fine_rows = [fine for fine in data["fine"] if fine["member_id"] == member_id]
    assessed = sum(float(fine["amount"] or 0) for fine in fine_rows)
    paid = sum(float(fine["paid_amount"] or 0) for fine in fine_rows)
    return {
        "ok": True,
        "member_id": member_id,
        "assessed": round(assessed, 2),
        "paid": round(paid, 2),
        "outstanding": round(assessed - paid, 2),
        "fine_count": len(fine_rows),
    }


def load_kpi_summary():
    path = ROOT / "outputs" / "kpi_summary.csv"
    if not path.exists():
        return {"ok": False, "message": "KPI summary file was not found. Run build_project.py first."}
    rows = []
    with path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    return {"ok": True, "kpis": {row["metric"]: row["value"] for row in rows}}


def purchase_recommendations(limit=5):
    path = ROOT / "outputs" / "looker_book_demand.csv"
    if not path.exists():
        return {"ok": False, "message": "Book demand file was not found. Run build_project.py first."}
    with path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    rows.sort(key=lambda row: float(row["purchase_need_score"] or 0), reverse=True)
    return {
        "ok": True,
        "recommendations": rows[:limit],
    }


if __name__ == "__main__":
    data = load_data()
    print("University Library Chatbot Demo")
    print(search_books(data, "database"))
    print(reserve_book(data, "M000001", "B000001"))
    print(check_loan_status(data, "M000001"))
    print(check_fines(data, "M000001"))
    print(load_kpi_summary())
    print(purchase_recommendations(3))
'''
    (ROOT / "library_chatbot.py").write_text(chatbot_code, encoding="utf-8")

    telegram_code = r'''from __future__ import annotations

import json
import os
import time
import traceback
import urllib.parse
import urllib.request

import library_chatbot as core


TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
API_BASE = f"https://api.telegram.org/bot{TOKEN}"


def api_call(method, payload=None):
    if not TOKEN:
        raise RuntimeError("Set TELEGRAM_BOT_TOKEN before running this bot.")
    data = urllib.parse.urlencode(payload or {}).encode("utf-8")
    with urllib.request.urlopen(f"{API_BASE}/{method}", data=data, timeout=40) as response:
        return json.loads(response.read().decode("utf-8"))


def send_message(chat_id, text):
    return api_call(
        "sendMessage",
        {
            "chat_id": chat_id,
            "text": text[:3900],
            "parse_mode": "HTML",
            "disable_web_page_preview": True,
        },
    )


def format_search(result):
    if not result["ok"]:
        return result["message"]
    lines = ["<b>Search results</b>"]
    for row in result["results"][:5]:
        lines.append(
            f"{row['book_id']} | {row['title']}\n"
            f"Category: {row['category']} | Language: {row['language']} | Available: {row['available_copies']}"
        )
    return "\n\n".join(lines)


def format_loans(result):
    if not result["ok"]:
        return result["message"]
    if not result["open_loans"]:
        return f"No active, overdue, or lost loans found for {result['member_id']}."
    lines = [f"<b>Open loans for {result['member_id']}</b>"]
    for row in result["open_loans"][:10]:
        lines.append(f"{row['loan_id']} | {row['status']} | Due: {row['due_date']}\n{row['title']}")
    return "\n\n".join(lines)


def format_fines(result):
    if not result["ok"]:
        return result["message"]
    return (
        f"<b>Fine summary for {result['member_id']}</b>\n"
        f"Assessed: {result['assessed']:.2f}\n"
        f"Paid: {result['paid']:.2f}\n"
        f"Outstanding: {result['outstanding']:.2f}\n"
        f"Fine records: {result['fine_count']}"
    )


def format_kpis():
    result = core.load_kpi_summary()
    if not result["ok"]:
        return result["message"]
    kpis = result["kpis"]
    return (
        "<b>Manager KPI Summary</b>\n"
        f"Total loans: {kpis.get('total_loans', '-')}\n"
        f"Active loans: {kpis.get('active_loans', '-')}\n"
        f"Overdue loans: {kpis.get('overdue_loans', '-')}\n"
        f"Overdue rate: {kpis.get('overdue_rate_percent', '-')}%\n"
        f"Available copies: {kpis.get('available_copies', '-')}\n"
        f"Waiting reservations: {kpis.get('waiting_reservations', '-')}\n"
        f"Fine balance: {kpis.get('fine_balance', '-')}"
    )


def format_purchase_needs():
    result = core.purchase_recommendations(5)
    if not result["ok"]:
        return result["message"]
    lines = ["<b>Top Purchase Recommendations</b>"]
    for row in result["recommendations"]:
        lines.append(
            f"{row['book_id']} | {row['title']}\n"
            f"Category: {row['category_name']} | Score: {row['purchase_need_score']} | "
            f"Loans: {row['loan_count']} | Reservations: {row['reservation_count']} | Available: {row['available_copies']}"
        )
    return "\n\n".join(lines)


def help_text():
    return (
        "<b>Central University Library Bot</b>\n"
        "Commands:\n"
        "/search keyword\n"
        "/reserve MEMBER_ID BOOK_ID\n"
        "/loans MEMBER_ID\n"
        "/fines MEMBER_ID\n"
        "/report_issue MEMBER_ID LOAN_ID lost|damaged\n"
        "/kpis\n"
        "/purchase_needs"
    )


def handle_message(data, text):
    text = (text or "").strip()
    if not text or text == "/start" or text == "/help":
        return help_text()

    parts = text.split()
    command = parts[0].lower()

    if command == "/search":
        if len(parts) < 2:
            return "Please write a search term. Example: /search database"
        return format_search(core.search_books(data, " ".join(parts[1:])))

    if command == "/reserve":
        if len(parts) != 3:
            return "Use this format: /reserve MEMBER_ID BOOK_ID"
        result = core.reserve_book(data, parts[1], parts[2])
        return result["message"]

    if command == "/loans":
        if len(parts) != 2:
            return "Use this format: /loans MEMBER_ID"
        return format_loans(core.check_loan_status(data, parts[1]))

    if command == "/fines":
        if len(parts) != 2:
            return "Use this format: /fines MEMBER_ID"
        return format_fines(core.check_fines(data, parts[1]))

    if command == "/report_issue":
        if len(parts) != 4:
            return "Use this format: /report_issue MEMBER_ID LOAN_ID lost|damaged"
        result = core.report_lost_or_damaged(data, parts[1], parts[2], parts[3].lower())
        return result["message"]

    if command == "/kpis":
        return format_kpis()

    if command == "/purchase_needs":
        return format_purchase_needs()

    return "Unknown command.\n\n" + help_text()


def main():
    data = core.load_data()
    offset = 0
    print("Telegram bot is running. Press Ctrl+C to stop.")
    while True:
        try:
            response = api_call("getUpdates", {"offset": offset, "timeout": 30})
            for update in response.get("result", []):
                offset = update["update_id"] + 1
                message = update.get("message") or update.get("edited_message")
                if not message:
                    continue
                chat_id = message["chat"]["id"]
                reply = handle_message(data, message.get("text", ""))
                send_message(chat_id, reply)
        except KeyboardInterrupt:
            print("Stopped.")
            return
        except Exception:
            traceback.print_exc()
            time.sleep(5)


if __name__ == "__main__":
    main()
'''
    (ROOT / "telegram_bot.py").write_text(telegram_code, encoding="utf-8")

    telegram_readme = """# Telegram Bot Deployment Guide

## What This Bot Does

The Telegram bot uses the same validation rules as the project chatbot:

- Searches books.
- Reserves books after checking member and book validity.
- Checks active/overdue loans.
- Checks fine balances.
- Records lost/damaged item reports as validated tracking responses.
- Shows manager KPIs.
- Shows purchase-need recommendations.

## Commands

```text
/start
/search database
/reserve M000001 B000001
/loans M000001
/fines M000001
/report_issue M000001 LN000123 damaged
/kpis
/purchase_needs
```

## Run in Google Colab

```python
import os
os.environ["TELEGRAM_BOT_TOKEN"] = "PASTE_YOUR_BOTFATHER_TOKEN_HERE"
!python telegram_bot.py
```

Keep the Colab cell running while testing the bot in Telegram.

## Submission Note

Create the Telegram bot through BotFather, test the commands, then paste the bot link or username into `report/final_report.md`.
"""
    (ROOT / "telegram_deployment.md").write_text(telegram_readme, encoding="utf-8")


def generate_colab_runbook() -> None:
    runbook = f"""# Google Colab Runbook

Project: {PROJECT_TITLE}
Student: {STUDENT_NAME}

## Step 1: Upload the Project Folder

Upload the full `university_library_bi` folder to Google Drive, then open Google Colab.

## Step 2: Mount Google Drive

```python
from google.colab import drive
drive.mount('/content/drive')
```

## Step 3: Go to the Project Folder

Change the path if your folder is somewhere else.

```python
%cd /content/drive/MyDrive/university_library_bi
```

## Step 4: Build the Dataset and Deliverables

```python
!python build_project.py
```

## Step 5: Check the Generated Files

```python
import pandas as pd
pd.read_csv('outputs/kpi_summary.csv')
```

Open the local dashboard preview:

```python
from IPython.display import HTML
HTML(filename='dashboard/dashboard_preview.html')
```

## Step 6: Test the Chatbot Logic

```python
import library_chatbot as bot
data = bot.load_data()
bot.search_books(data, 'database')
```

```python
bot.reserve_book(data, 'M000001', 'B000001')
```

Manager checks:

```python
bot.load_kpi_summary()
bot.purchase_recommendations(5)
```

## Step 7: Use the Data in Looker Studio

Upload these CSV files to Google Sheets:

- `outputs/looker_loan_detail.csv`
- `outputs/looker_reservation_detail.csv`
- `outputs/looker_fine_detail.csv`
- `outputs/looker_book_demand.csv`
- `outputs/kpi_summary.csv`

Then connect those Google Sheets to Looker Studio and build the three pages described in `dashboard_blueprint.md`.

Required Looker pages:

1. Manager page.
2. Analyst/operator page.
3. External user/member page.

Required filters:

- Date range.
- Branch.
- Category.
- Member type.
- Loan status.

## Step 8: Run the Telegram Bot

Create a Telegram bot with BotFather, copy the token, then run:

```python
import os
os.environ["TELEGRAM_BOT_TOKEN"] = "PASTE_YOUR_BOTFATHER_TOKEN_HERE"
!python telegram_bot.py
```

Keep the Colab cell running while you test these Telegram commands:

```text
/start
/search database
/reserve M000001 B000001
/loans M000001
/fines M000001
/kpis
/purchase_needs
```

## Step 9: Final Submission Checklist

- Replace placeholder dashboard link in `report/final_report.md`.
- Replace placeholder Telegram bot link/user name in `report/final_report.md`.
- Share Looker Studio access with the instructor.
- Send the final report, dashboard link, Telegram bot link, and access details by {DELIVERY_DATE}.
"""
    (ROOT / "colab_runbook.md").write_text(runbook, encoding="utf-8")


def generate_readme(row_counts: dict[str, int]) -> None:
    readme = f"""# {PROJECT_TITLE}

Complete BI course project for Topic #11: University Library.

- Student: {STUDENT_NAME}
- Course: {COURSE_NAME}
- University: {UNIVERSITY_NAME}
- Professor: {PROFESSOR_NAME}
- Delivery date: {DELIVERY_DATE}
- Dataset: {DATA_POSITIONING}

## Generated Deliverables

- `data/`: normalized CSV tables matching the ERD and SQL schema.
- `db/university_library.db`: SQLite database created from `schema.sql`.
- `outputs/`: Looker Studio friendly CSV exports and KPI summary.
- `dashboard/dashboard_preview.html`: local dashboard preview.
- `report/final_report.md`: final report text following the required template.
- `report/final_report.html`: browser-readable report.
- `dashboard_blueprint.md`: exact Looker Studio page/chart plan.
- `chatbot_design.md`: Telegram chatbot roles, scenarios, validation rules, and sample dialogue.
- `library_chatbot.py`: runnable chatbot validation logic.
- `telegram_bot.py`: Telegram Bot API wrapper.
- `telegram_deployment.md`: Telegram setup guide.
- `colab_runbook.md`: step-by-step Google Colab instructions.

## Dataset Size

| Table | Rows |
|---|---:|
"""
    for table, count in row_counts.items():
        readme += f"| {table} | {count:,} |\n"
    readme += """
## Build Again

Run:

```bash
python build_project.py
```

In Google Colab, upload this folder and run the same command from inside the folder.

## Looker Studio

Use the CSV files in `outputs/` for the dashboard. They are easier than connecting all 12 normalized tables directly.

Recommended production files:

- `outputs/looker_loan_detail.csv`
- `outputs/looker_reservation_detail.csv`
- `outputs/looker_fine_detail.csv`
- `outputs/looker_book_demand.csv`
- `outputs/kpi_summary.csv`

## Telegram

Run:

```bash
python library_chatbot.py
```

For Telegram deployment, create a bot with BotFather, set `TELEGRAM_BOT_TOKEN`, then run:

```bash
python telegram_bot.py
```
"""
    (ROOT / "README.md").write_text(readme, encoding="utf-8")


def validate_database(conn: sqlite3.Connection, row_counts: dict[str, int]) -> list[str]:
    checks = []
    fk_errors = conn.execute("PRAGMA foreign_key_check").fetchall()
    checks.append(f"foreign_key_errors={len(fk_errors)}")
    for table, count in row_counts.items():
        db_count = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
        if db_count != count:
            raise RuntimeError(f"Row count mismatch for {table}: CSV {count}, DB {db_count}")
        checks.append(f"{table}={db_count}")
    bad_returns = conn.execute(
        """
        SELECT COUNT(*) FROM loan
        WHERE (loan_status = 'returned' AND return_date IS NULL)
           OR (loan_status IN ('active', 'overdue', 'lost') AND return_date IS NOT NULL)
        """
    ).fetchone()[0]
    checks.append(f"loan_status_date_errors={bad_returns}")
    if fk_errors or bad_returns:
        raise RuntimeError("Validation failed: " + "; ".join(checks))
    return checks


def build() -> None:
    for directory in [DATA_DIR, OUTPUT_DIR, REPORT_DIR, DASHBOARD_DIR, DB_DIR]:
        directory.mkdir(parents=True, exist_ok=True)

    reference = generate_reference_data()
    members = generate_members(reference["library_branch"])
    books, book_authors = generate_books(reference)
    copies = generate_copies(books, reference["category"], reference["library_branch"])
    loans, _, _ = generate_loans(members, copies, reference["librarian"])
    reservations = generate_reservations(members, books, copies, loans, reference["librarian"])
    fines = generate_fines(members, copies, loans)

    rows_by_table = {
        "library_branch": reference["library_branch"],
        "member": members,
        "librarian": reference["librarian"],
        "publisher": reference["publisher"],
        "category": reference["category"],
        "author": reference["author"],
        "book": books,
        "book_author": book_authors,
        "book_copy": copies,
        "loan": loans,
        "reservation": reservations,
        "fine": fines,
    }
    rows_by_table = {
        table: [clean_row(row, TABLE_FIELDS[table]) for row in rows]
        for table, rows in rows_by_table.items()
    }
    row_counts = {table: len(rows) for table, rows in rows_by_table.items()}

    export_csvs(rows_by_table)
    conn = create_database(rows_by_table)
    checks = validate_database(conn, row_counts)
    metrics = compute_metrics(conn)
    export_looker_views(conn, metrics)
    generate_report(metrics, row_counts)
    generate_dashboard(metrics)
    generate_dashboard_blueprint()
    generate_chatbot_files()
    generate_colab_runbook()
    generate_readme(row_counts)

    validation_summary = {
        "generated_on": TODAY.isoformat(),
        "row_counts": row_counts,
        "validation": checks,
        "key_metrics": {
            "total_loans": metrics["total_loans"],
            "overdue_rate_percent": metrics["overdue_rate"],
            "available_copies": metrics["available_copies"],
            "fine_balance": round(metrics["fine_balance"], 2),
        },
    }
    (OUTPUT_DIR / "validation_summary.json").write_text(json.dumps(validation_summary, indent=2), encoding="utf-8")

    print("University Library BI project generated.")
    print(json.dumps(validation_summary, indent=2))


if __name__ == "__main__":
    build()
