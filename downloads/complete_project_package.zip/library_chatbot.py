from __future__ import annotations

import csv
from datetime import date
from pathlib import Path


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
TODAY = date(2026, 7, 8)


def load_csv(name):
    with (DATA_DIR / f"{name}.csv").open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def load_data():
    data = {
        "member": load_csv("member"),
        "book": load_csv("book"),
        "book_copy": load_csv("book_copy"),
        "loan": load_csv("loan"),
        "reservation": load_csv("reservation"),
        "fine": load_csv("fine"),
        "category": load_csv("category"),
    }
    return data


def by_id(rows, key):
    return {row[key]: row for row in rows}


def member_fine_balance(data, member_id):
    total = 0.0
    for fine in data["fine"]:
        if fine["member_id"] == member_id and fine["fine_status"] != "waived":
            total += float(fine["amount"] or 0) - float(fine["paid_amount"] or 0)
    return round(total, 2)


def available_copies(data, book_id):
    return [
        copy for copy in data["book_copy"]
        if copy["book_id"] == book_id and copy["availability_status"] == "available" and copy["is_reference_only"] == "0"
    ]


def search_books(data, text):
    text = text.strip().lower()
    if not text:
        return {"ok": False, "message": "Search text is required."}
    categories = by_id(data["category"], "category_id")
    results = []
    for book in data["book"]:
        category = categories[book["category_id"]]["category_name"]
        haystack = f"{book['book_id']} {book['title']} {category} {book['language']}".lower()
        if text in haystack:
            results.append({
                "book_id": book["book_id"],
                "title": book["title"],
                "category": category,
                "language": book["language"],
                "available_copies": len(available_copies(data, book["book_id"])),
            })
    if not results:
        return {"ok": False, "message": "No matching books were found."}
    return {"ok": True, "results": results[:10]}


def reserve_book(data, member_id, book_id):
    members = by_id(data["member"], "member_id")
    books = by_id(data["book"], "book_id")
    if member_id not in members:
        return {"ok": False, "message": "Member ID was not found. Please check the ID."}
    member = members[member_id]
    if member["status"] != "active":
        return {"ok": False, "message": f"Reservation rejected because member status is {member['status']}."}
    if date.fromisoformat(member["expiry_date"]) < TODAY:
        return {"ok": False, "message": "Reservation rejected because membership is expired."}
    if book_id not in books:
        return {"ok": False, "message": "Book ID was not found. Please check the ID."}
    for reservation in data["reservation"]:
        if (
            reservation["member_id"] == member_id
            and reservation["book_id"] == book_id
            and reservation["reservation_status"] in {"waiting", "ready_for_pickup"}
        ):
            return {"ok": False, "message": "Duplicate reservation rejected. This member already has an active reservation for the book."}
    fine_balance = member_fine_balance(data, member_id)
    if fine_balance > 35:
        return {"ok": False, "message": f"Reservation rejected because outstanding fines are {fine_balance:.2f}."}
    copies = available_copies(data, book_id)
    tracking = f"RSV-{TODAY.strftime('%Y%m%d')}-{member_id[-3:]}-{book_id[-3:]}"
    if copies:
        return {"ok": True, "tracking": tracking, "message": f"Reservation accepted. {len(copies)} available copy/copies found. Tracking number: {tracking}."}
    return {"ok": True, "tracking": tracking, "message": f"No available copy right now, but the reservation was added to the waiting queue. Tracking number: {tracking}."}


def check_loan_status(data, member_id):
    members = by_id(data["member"], "member_id")
    if member_id not in members:
        return {"ok": False, "message": "Member ID was not found."}
    copies = by_id(data["book_copy"], "copy_id")
    books = by_id(data["book"], "book_id")
    rows = []
    for loan in data["loan"]:
        if loan["member_id"] == member_id and loan["loan_status"] in {"active", "overdue", "lost"}:
            copy = copies[loan["copy_id"]]
            book = books[copy["book_id"]]
            rows.append({
                "loan_id": loan["loan_id"],
                "title": book["title"],
                "due_date": loan["due_date"],
                "status": loan["loan_status"],
            })
    return {"ok": True, "member_id": member_id, "open_loans": rows}


def report_lost_or_damaged(data, member_id, loan_id, issue_type):
    if issue_type not in {"lost", "damaged"}:
        return {"ok": False, "message": "Issue type must be lost or damaged."}
    members = by_id(data["member"], "member_id")
    if member_id not in members:
        return {"ok": False, "message": "Member ID was not found."}
    loans = by_id(data["loan"], "loan_id")
    if loan_id not in loans:
        return {"ok": False, "message": "Loan ID was not found."}
    loan = loans[loan_id]
    if loan["member_id"] != member_id:
        return {"ok": False, "message": "Loan does not belong to this member."}
    if loan["loan_status"] not in {"active", "overdue"}:
        return {"ok": False, "message": f"Only active or overdue loans can be reported. Current status is {loan['loan_status']}."}
    tracking = f"CASE-{TODAY.strftime('%Y%m%d')}-{loan_id[-4:]}"
    return {"ok": True, "tracking": tracking, "message": f"{issue_type.title()} item report received. Tracking number: {tracking}. Library staff must review the copy and confirm any fine."}


def check_fines(data, member_id):
    members = by_id(data["member"], "member_id")
    if member_id not in members:
        return {"ok": False, "message": "Member ID was not found."}
    fine_rows = [fine for fine in data["fine"] if fine["member_id"] == member_id]
    assessed = sum(float(fine["amount"] or 0) for fine in fine_rows)
    paid = sum(float(fine["paid_amount"] or 0) for fine in fine_rows)
    return {
        "ok": True,
        "member_id": member_id,
        "assessed": round(assessed, 2),
        "paid": round(paid, 2),
        "outstanding": round(assessed - paid, 2),
        "fine_count": len(fine_rows),
    }


def load_kpi_summary():
    path = ROOT / "outputs" / "kpi_summary.csv"
    if not path.exists():
        return {"ok": False, "message": "KPI summary file was not found. Run build_project.py first."}
    rows = []
    with path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    return {"ok": True, "kpis": {row["metric"]: row["value"] for row in rows}}


def purchase_recommendations(limit=5):
    path = ROOT / "outputs" / "looker_book_demand.csv"
    if not path.exists():
        return {"ok": False, "message": "Book demand file was not found. Run build_project.py first."}
    with path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    rows.sort(key=lambda row: float(row["purchase_need_score"] or 0), reverse=True)
    return {
        "ok": True,
        "recommendations": rows[:limit],
    }


if __name__ == "__main__":
    data = load_data()
    print("University Library Chatbot Demo")
    print(search_books(data, "database"))
    print(reserve_book(data, "M000001", "B000001"))
    print(check_loan_status(data, "M000001"))
    print(check_fines(data, "M000001"))
    print(load_kpi_summary())
    print(purchase_recommendations(3))
