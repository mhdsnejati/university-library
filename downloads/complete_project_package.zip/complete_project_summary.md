# Complete Project Summary

## Project Identity

- Project title: Central University Library Management System
- Topic: Topic #11 - University Library
- Student: Mohadese Nejati
- Course: Business Intelligence
- University: Sharif University
- Professor: Dr. Ghodosi
- Report language: English
- Delivery date: 20 Mordad

## What Was Built

This project was completed as a professional Business Intelligence course package for a university library system.

The package includes:

- ERD and table structure.
- SQL database schema.
- Close-to-real assumed operational dataset.
- Normalized CSV tables.
- SQLite database.
- Looker Studio-ready CSV exports.
- Modern dashboard preview.
- Final analytical report.
- Looker Studio build guide.
- Telegram chatbot design.
- Runnable chatbot validation logic.
- Telegram bot wrapper.
- Google Colab runbook.
- One-file browser viewer.
- One zip package containing the project.

## Data Positioning

The data is close-to-real assumed operational data. It is not an official Sharif University library export, but it is designed to behave like a real university library dataset.

The data follows:

- Unique primary keys.
- Valid foreign keys.
- Logical date ranges.
- Realistic loan and reservation behavior.
- Book-copy availability rules.
- Fine/payment consistency.
- Member status and membership rules.
- Reservation queue logic.
- Purchase-need scoring.

## Dataset Size

| Table | Rows |
|---|---:|
| library_branch | 4 |
| member | 520 |
| librarian | 18 |
| publisher | 32 |
| category | 18 |
| author | 180 |
| book | 320 |
| book_author | 456 |
| book_copy | 1,024 |
| loan | 2,200 |
| reservation | 650 |
| fine | 408 |

## Key Metrics

| Metric | Value |
|---|---:|
| Total loans | 2,200 |
| Active loans | 24 |
| Overdue loans | 15 |
| Overdue rate among open loans | 38.46% |
| Available copies | 889 |
| Availability rate | 86.82% |
| Total reservations | 650 |
| Waiting reservations | 105 |
| Fine balance | 2,349.69 |
| Paid fines | 3,224.45 |

## Validation Results

Validation passed.

- Foreign-key errors: 0
- Loan status/date errors: 0
- Python files compile successfully.
- Core chatbot runs successfully.
- Telegram command routing works locally.
- Looker book-demand export includes all 320 books.

## ERD and Database Structure

The ERD contains 12 entities:

1. LibraryBranch
2. Member
3. Librarian
4. Publisher
5. Category
6. Author
7. Book
8. BookAuthor
9. BookCopy
10. Loan
11. Reservation
12. Fine

Important relationships:

- One branch has many members, librarians, and book copies.
- One publisher publishes many books.
- One category classifies many books.
- Books and authors have a many-to-many relationship through BookAuthor.
- One book has many physical copies.
- One member has many loans, reservations, and fines.
- One loan is linked to one member and one physical copy.
- One reservation is linked to one member and one book title.
- One fine is linked to one member and one loan.

Important business rules:

- A member must be active to borrow or reserve books.
- A loan is created for a physical copy.
- A reservation is created for a book title.
- Reference-only copies cannot be borrowed.
- due_date must be after checkout_date.
- Returned loans must have a return_date.
- Active, overdue, and lost loans must not have a return_date.
- Waiting reservations must have queue_position.
- paid_amount cannot exceed amount.

## Dashboard Work

A modern professional dashboard preview was created.

File:

```text
dashboard/dashboard_preview.html
```

Dashboard pages:

1. Manager page
2. Analyst/operator page
3. External user/member page
4. Looker Studio production setup section

Manager page includes:

- Total loans KPI.
- Overdue rate KPI.
- Available copies KPI.
- Outstanding fine balance KPI.
- Monthly borrowing trend.
- Loans by branch.
- Purchase-need ranking.
- Management insight cards.

Analyst/operator page includes:

- Active loans KPI.
- Overdue loans KPI.
- Waiting reservations KPI.
- Returned loans KPI.
- Overdue loans by category.
- Librarian checkout workload.

External user/member page includes:

- Availability rate KPI.
- Total reservations KPI.
- Paid fines KPI.
- Lost loans KPI.
- Reservation status.
- Member type usage.
- Most borrowed titles.

## Looker Studio Work

A full Looker Studio build guide was created.

File:

```text
dashboard_blueprint.md
```

Looker-ready CSV exports were created:

```text
outputs/looker_loan_detail.csv
outputs/looker_reservation_detail.csv
outputs/looker_fine_detail.csv
outputs/looker_book_demand.csv
outputs/kpi_summary.csv
```

Recommended Looker Studio pages:

1. Manager
2. Analyst/operator
3. External user/member

Recommended filters:

- Date range.
- Branch.
- Category.
- Member type.
- Loan status.
- Librarian.

Recommended charts:

- KPI cards.
- Time series.
- Bar charts.
- Donut chart.
- Ranking table.
- Searchable table.
- Operational table.

Important note:

The final Looker Studio dashboard must still be created/published manually in the user's Google account, because that requires account access.

## Report Work

The final report was created in both Markdown and HTML.

Files:

```text
report/final_report.md
report/final_report.html
```

The report includes:

- Title page.
- Executive summary.
- System and stakeholder introduction.
- Main processes and business rules.
- Data model and ERD explanation.
- Data generation method and quality controls.
- Looker Studio dashboard description.
- Reports needed by each role.
- Telegram chatbot design.
- Final analysis, limitations, and suggestions.

## Chatbot Work

The chatbot section was completed for Telegram.

Files:

```text
chatbot_design.md
library_chatbot.py
telegram_bot.py
telegram_deployment.md
```

The chatbot supports:

- Book search.
- Book reservation.
- Loan status check.
- Fine check.
- Lost/damaged book report.
- Manager KPI summary.
- Purchase-need recommendations.

Telegram commands:

```text
/start
/search database
/reserve M000001 B000001
/loans M000001
/fines M000001
/report_issue M000001 LN000123 damaged
/kpis
/purchase_needs
```

Validation rules:

- Member ID must exist.
- Member must be active for reservation.
- Membership must not be expired.
- Book ID must exist.
- Duplicate active reservations are rejected.
- Serious unpaid fines block reservation.
- Loan must belong to the member for lost/damaged reports.
- Issue type must be lost or damaged.

Important note:

Telegram deployment requires a BotFather token. The bot can be run in Google Colab or another Python environment.

## Google Colab Work

A Colab runbook was created.

File:

```text
colab_runbook.md
```

It explains how to:

- Upload the folder to Google Drive.
- Mount Drive in Colab.
- Run `build_project.py`.
- View KPI output.
- Preview the dashboard.
- Test chatbot logic.
- Upload CSV files to Google Sheets.
- Build Looker Studio pages.
- Run the Telegram bot.

## One-File Viewer

A single browser page was created to view the whole project in one place.

File:

```text
complete_project.html
```

This file includes:

- Dashboard preview.
- Final report.
- Looker Studio guide.
- Telegram guide.
- Colab steps.
- ERD/table structure.
- Data checklist.

Open it directly in a browser:

```text
file:///C:/Users/Asus%20Zenbook/Documents/AP/university_library_bi/complete_project.html
```

## One-File Package

A zip package was created.

File:

```text
complete_project_package.zip
```

It contains:

- Report files.
- Dashboard files.
- Data CSV files.
- Looker CSV exports.
- SQLite database.
- SQL schema.
- Chatbot files.
- Telegram files.
- Colab instructions.
- Documentation.

## How To Run or View

### View Everything

Open:

```text
complete_project.html
```

### View Final Report

Open:

```text
report/final_report.html
```

### View Dashboard Preview

Open:

```text
dashboard/dashboard_preview.html
```

### Rebuild Everything

In PowerShell:

```powershell
cd "C:\Users\Asus Zenbook\Documents\AP\university_library_bi"
python build_project.py
```

### Test Core Chatbot

```powershell
python library_chatbot.py
```

### Run Telegram Bot

First create a bot token with BotFather, then:

```powershell
$env:TELEGRAM_BOT_TOKEN="PASTE_YOUR_TOKEN_HERE"
python telegram_bot.py
```

### Recreate One-File Viewer and Zip

```powershell
python make_single_file.py
```

## Final Files Created

Main project files:

```text
README.md
complete_project.html
complete_project_package.zip
complete_project_summary.md
schema.sql
erd_table_structure.md
real_data_source_plan.md
dashboard_blueprint.md
chatbot_design.md
telegram_deployment.md
colab_runbook.md
build_project.py
library_chatbot.py
telegram_bot.py
make_single_file.py
```

Generated folders:

```text
data/
outputs/
report/
dashboard/
db/
```

## What Still Requires User Account Access

Two things must be done manually:

1. Publish the Looker Studio dashboard using the user's Google account.
2. Create and test the Telegram bot using a BotFather token.

After those are done, update these lines in the report:

```text
Looker Studio dashboard link: To be added after publishing
Telegram chatbot link/user name: To be added after publishing
```

